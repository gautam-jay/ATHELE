import { ScrollView, View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import SafeAreaWrapper from '@/components/SafeAreaWrapper';
import Card from '@/components/Card';
import Button from '@/components/Button';
import { ClipboardList, User, Activity, Target, Clock, ChevronRight, CircleCheck as CheckCircle } from 'lucide-react-native';

export default function AssessmentScreen() {
  const assessments = [
    {
      id: 1,
      title: 'Movement Screen',
      description: 'Assess your movement quality and identify potential risk factors',
      duration: '15 min',
      status: 'not-started',
      icon: Activity,
      color: '#2563EB',
    },
    {
      id: 2,
      title: 'Sport-Specific Assessment',
      description: 'Evaluate risks specific to your sport and position',
      duration: '20 min',
      status: 'completed',
      icon: Target,
      color: '#10B981',
    },
    {
      id: 3,
      title: 'Injury History',
      description: 'Document your previous injuries and recovery patterns',
      duration: '10 min',
      status: 'in-progress',
      icon: ClipboardList,
      color: '#F59E0B',
    },
    {
      id: 4,
      title: 'Lifestyle Factors',
      description: 'Analyze sleep, nutrition, and training load patterns',
      duration: '12 min',
      status: 'not-started',
      icon: User,
      color: '#0891B2',
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return '#10B981';
      case 'in-progress':
        return '#F59E0B';
      default:
        return '#64748B';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed':
        return 'Completed';
      case 'in-progress':
        return 'In Progress';
      default:
        return 'Not Started';
    }
  };

  return (
    <SafeAreaWrapper>
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Risk Assessment</Text>
          <Text style={styles.subtitle}>
            Complete these assessments to get personalized injury prevention recommendations
          </Text>
        </View>

        {/* Progress Overview */}
        <Card style={styles.progressCard}>
          <View style={styles.progressHeader}>
            <Text style={styles.progressTitle}>Assessment Progress</Text>
            <Text style={styles.progressPercent}>25%</Text>
          </View>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { width: '25%' }]} />
          </View>
          <Text style={styles.progressText}>1 of 4 assessments completed</Text>
        </Card>

        {/* Assessment List */}
        <View style={styles.assessmentList}>
          {assessments.map((assessment) => {
            const IconComponent = assessment.icon;
            return (
              <Card key={assessment.id} style={styles.assessmentCard}>
                <TouchableOpacity style={styles.assessmentContent}>
                  <View style={styles.assessmentHeader}>
                    <View style={[styles.assessmentIcon, { backgroundColor: assessment.color + '20' }]}>
                      <IconComponent size={24} color={assessment.color} />
                    </View>
                    <View style={styles.assessmentInfo}>
                      <Text style={styles.assessmentTitle}>{assessment.title}</Text>
                      <Text style={styles.assessmentDescription}>{assessment.description}</Text>
                      <View style={styles.assessmentMeta}>
                        <Clock size={14} color="#64748B" />
                        <Text style={styles.assessmentDuration}>{assessment.duration}</Text>
                        <View style={styles.assessmentStatus}>
                          <View 
                            style={[
                              styles.statusDot, 
                              { backgroundColor: getStatusColor(assessment.status) }
                            ]} 
                          />
                          <Text style={[styles.statusText, { color: getStatusColor(assessment.status) }]}>
                            {getStatusText(assessment.status)}
                          </Text>
                        </View>
                      </View>
                    </View>
                    <ChevronRight size={20} color="#64748B" />
                  </View>
                </TouchableOpacity>
              </Card>
            );
          })}
        </View>

        {/* Quick Assessment */}
        <Card style={styles.quickAssessmentCard}>
          <Text style={styles.quickAssessmentTitle}>Quick Daily Check-in</Text>
          <Text style={styles.quickAssessmentDescription}>
            Answer a few quick questions about how you're feeling today
          </Text>
          <Button
            title="Start 2-Minute Check-in"
            onPress={() => {}}
            variant="outline"
            style={styles.quickAssessmentButton}
          />
        </Card>

        {/* Recent Results */}
        <Card>
          <Text style={styles.resultsTitle}>Recent Assessment Results</Text>
          <View style={styles.resultItem}>
            <View style={styles.resultIcon}>
              <CheckCircle size={20} color="#10B981" />
            </View>
            <View style={styles.resultContent}>
              <Text style={styles.resultTitle}>Sport-Specific Assessment</Text>
              <Text style={styles.resultDate}>Completed 3 days ago</Text>
              <Text style={styles.resultSummary}>
                Good mobility, focus on hamstring flexibility
              </Text>
            </View>
          </View>
        </Card>
      </ScrollView>
    </SafeAreaWrapper>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#0F172A',
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginTop: 8,
    lineHeight: 22,
  },
  progressCard: {
    marginHorizontal: 20,
    backgroundColor: '#F8FAFC',
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  progressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  progressTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
  },
  progressPercent: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: '#2563EB',
  },
  progressBar: {
    height: 8,
    backgroundColor: '#E2E8F0',
    borderRadius: 4,
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#2563EB',
    borderRadius: 4,
  },
  progressText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
  assessmentList: {
    paddingHorizontal: 20,
  },
  assessmentCard: {
    marginBottom: 12,
  },
  assessmentContent: {
    margin: -20,
    padding: 20,
  },
  assessmentHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  assessmentIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  assessmentInfo: {
    flex: 1,
  },
  assessmentTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginBottom: 4,
  },
  assessmentDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginBottom: 8,
    lineHeight: 20,
  },
  assessmentMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  assessmentDuration: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
  assessmentStatus: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: 8,
  },
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    marginRight: 4,
  },
  statusText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
  },
  quickAssessmentCard: {
    marginHorizontal: 20,
    backgroundColor: '#F0F9FF',
    borderWidth: 1,
    borderColor: '#BAE6FD',
  },
  quickAssessmentTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginBottom: 8,
  },
  quickAssessmentDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginBottom: 16,
    lineHeight: 20,
  },
  quickAssessmentButton: {
    alignSelf: 'flex-start',
  },
  resultsTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginBottom: 16,
  },
  resultItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  resultIcon: {
    marginRight: 12,
    marginTop: 2,
  },
  resultContent: {
    flex: 1,
  },
  resultTitle: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginBottom: 4,
  },
  resultDate: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginBottom: 4,
  },
  resultSummary: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    lineHeight: 20,
  },
});