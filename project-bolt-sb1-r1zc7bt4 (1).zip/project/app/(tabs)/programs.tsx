import { ScrollView, View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import SafeAreaWrapper from '@/components/SafeAreaWrapper';
import Card from '@/components/Card';
import Button from '@/components/Button';
import { Target, Play, Clock, Trophy, Zap, ChevronRight, Star, CircleCheck as CheckCircle, Calendar, User, Activity, Shield } from 'lucide-react-native';

export default function ProgramsScreen() {
  // Mock user profile data - in real app this would come from user onboarding
  const userProfile = {
    sport: 'Soccer',
    position: 'Midfielder',
    level: 'High School Varsity',
    age: '16-18',
    riskFactors: ['Previous ankle injury', 'High training load'],
    goals: ['Prevent injuries', 'Improve performance']
  };

  const personalizedPlan = {
    title: 'Soccer Midfielder Prevention Program',
    description: 'Customized for your position, injury history, and performance goals',
    totalWeeks: 12,
    sessionsPerWeek: 4,
    avgSessionTime: '25 min',
    riskReduction: '73%',
    phases: [
      {
        name: 'Foundation Phase',
        weeks: '1-4',
        focus: 'Movement Quality & Stability',
        color: '#3B82F6'
      },
      {
        name: 'Strength Phase',
        weeks: '5-8',
        focus: 'Power & Resilience Building',
        color: '#10B981'
      },
      {
        name: 'Performance Phase',
        weeks: '9-12',
        focus: 'Sport-Specific Integration',
        color: '#F59E0B'
      }
    ]
  };

  const todaysWorkout = {
    title: 'Dynamic Warm-Up & Ankle Stability',
    phase: 'Foundation Phase - Week 2',
    duration: '20 min',
    exercises: [
      { name: 'Dynamic Leg Swings', duration: '2 min', completed: true },
      { name: 'Single-Leg Balance', duration: '3 min', completed: true },
      { name: 'Ankle Circles & Flexion', duration: '2 min', completed: false },
      { name: 'Lateral Lunges', duration: '3 min', completed: false },
      { name: 'Calf Raises Progression', duration: '3 min', completed: false },
      { name: 'Cool-down Stretches', duration: '7 min', completed: false }
    ],
    completedCount: 2,
    totalCount: 6
  };

  const weeklySchedule = [
    { day: 'Mon', type: 'Prevention', status: 'completed', focus: 'Lower Body' },
    { day: 'Tue', type: 'Recovery', status: 'completed', focus: 'Mobility' },
    { day: 'Wed', type: 'Prevention', status: 'current', focus: 'Ankle Stability' },
    { day: 'Thu', type: 'Strength', status: 'upcoming', focus: 'Core Power' },
    { day: 'Fri', type: 'Recovery', status: 'upcoming', focus: 'Active Rest' },
    { day: 'Sat', type: 'Prevention', status: 'upcoming', focus: 'Full Body' },
    { day: 'Sun', type: 'Rest', status: 'upcoming', focus: 'Complete Rest' }
  ];

  const progressStats = [
    { label: 'Program Progress', value: '18%', color: '#3B82F6' },
    { label: 'Weekly Completion', value: '67%', color: '#10B981' },
    { label: 'Streak Days', value: '12', color: '#F59E0B' },
    { label: 'Risk Reduction', value: '23%', color: '#EC4899' }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return '#10B981';
      case 'current': return '#3B82F6';
      case 'upcoming': return '#6B7280';
      default: return '#374151';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'Prevention': return Shield;
      case 'Strength': return Zap;
      case 'Recovery': return Activity;
      default: return Calendar;
    }
  };

  return (
    <SafeAreaWrapper>
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Your Personalized Plan</Text>
          <Text style={styles.subtitle}>
            Evidence-based program tailored specifically for you
          </Text>
        </View>

        {/* User Profile Summary */}
        <Card style={styles.profileCard}>
          <View style={styles.profileHeader}>
            <View style={styles.profileIcon}>
              <User size={24} color="#3B82F6" />
            </View>
            <View style={styles.profileInfo}>
              <Text style={styles.profileTitle}>Your Athletic Profile</Text>
              <Text style={styles.profileDetails}>
                {userProfile.sport} • {userProfile.position} • {userProfile.level}
              </Text>
            </View>
          </View>
          <View style={styles.profileTags}>
            {userProfile.riskFactors.map((factor, index) => (
              <View key={index} style={styles.riskTag}>
                <Text style={styles.riskTagText}>{factor}</Text>
              </View>
            ))}
          </View>
        </Card>

        {/* Program Overview */}
        <Card style={styles.programCard}>
          <View style={styles.programHeader}>
            <View style={styles.programIcon}>
              <Target size={28} color="#3B82F6" />
            </View>
            <View style={styles.programInfo}>
              <Text style={styles.programTitle}>{personalizedPlan.title}</Text>
              <Text style={styles.programDescription}>{personalizedPlan.description}</Text>
            </View>
          </View>

          <View style={styles.programStats}>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{personalizedPlan.totalWeeks}</Text>
              <Text style={styles.statLabel}>Weeks</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{personalizedPlan.sessionsPerWeek}</Text>
              <Text style={styles.statLabel}>Sessions/Week</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{personalizedPlan.avgSessionTime}</Text>
              <Text style={styles.statLabel}>Avg Time</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: '#10B981' }]}>{personalizedPlan.riskReduction}</Text>
              <Text style={styles.statLabel}>Risk Reduction</Text>
            </View>
          </View>

          <View style={styles.phases}>
            <Text style={styles.phasesTitle}>Program Phases</Text>
            {personalizedPlan.phases.map((phase, index) => (
              <View key={index} style={styles.phaseItem}>
                <View style={[styles.phaseIndicator, { backgroundColor: phase.color }]} />
                <View style={styles.phaseContent}>
                  <Text style={styles.phaseName}>{phase.name}</Text>
                  <Text style={styles.phaseWeeks}>Weeks {phase.weeks}</Text>
                  <Text style={styles.phaseFocus}>{phase.focus}</Text>
                </View>
              </View>
            ))}
          </View>
        </Card>

        {/* Progress Overview */}
        <Card>
          <Text style={styles.sectionTitle}>Your Progress</Text>
          <View style={styles.progressGrid}>
            {progressStats.map((stat, index) => (
              <View key={index} style={styles.progressItem}>
                <Text style={[styles.progressValue, { color: stat.color }]}>{stat.value}</Text>
                <Text style={styles.progressLabel}>{stat.label}</Text>
              </View>
            ))}
          </View>
        </Card>

        {/* Today's Workout */}
        <Card style={styles.workoutCard}>
          <View style={styles.workoutHeader}>
            <View style={styles.workoutInfo}>
              <Text style={styles.workoutTitle}>{todaysWorkout.title}</Text>
              <Text style={styles.workoutPhase}>{todaysWorkout.phase}</Text>
              <View style={styles.workoutMeta}>
                <Clock size={16} color="#94A3B8" />
                <Text style={styles.workoutDuration}>{todaysWorkout.duration}</Text>
              </View>
            </View>
            <TouchableOpacity style={styles.playButton}>
              <Play size={24} color="#FFFFFF" />
            </TouchableOpacity>
          </View>

          <View style={styles.workoutProgress}>
            <View style={styles.progressBar}>
              <View 
                style={[
                  styles.progressFill, 
                  { width: `${(todaysWorkout.completedCount / todaysWorkout.totalCount) * 100}%` }
                ]} 
              />
            </View>
            <Text style={styles.progressText}>
              {todaysWorkout.completedCount} of {todaysWorkout.totalCount} exercises completed
            </Text>
          </View>

          <View style={styles.exerciseList}>
            {todaysWorkout.exercises.slice(0, 3).map((exercise, index) => (
              <View key={index} style={styles.exerciseItem}>
                <View style={[
                  styles.exerciseCheck,
                  exercise.completed && styles.exerciseCheckCompleted
                ]}>
                  {exercise.completed && <CheckCircle size={16} color="#10B981" />}
                </View>
                <View style={styles.exerciseInfo}>
                  <Text style={[
                    styles.exerciseName,
                    exercise.completed && styles.exerciseNameCompleted
                  ]}>
                    {exercise.name}
                  </Text>
                  <Text style={styles.exerciseDuration}>{exercise.duration}</Text>
                </View>
              </View>
            ))}
            {todaysWorkout.exercises.length > 3 && (
              <Text style={styles.moreExercises}>
                +{todaysWorkout.exercises.length - 3} more exercises
              </Text>
            )}
          </View>

          <Button
            title="Continue Workout"
            onPress={() => {}}
            style={styles.continueButton}
          />
        </Card>

        {/* Weekly Schedule */}
        <Card>
          <View style={styles.scheduleHeader}>
            <Text style={styles.sectionTitle}>This Week's Schedule</Text>
            <TouchableOpacity>
              <Calendar size={20} color="#94A3B8" />
            </TouchableOpacity>
          </View>
          
          <View style={styles.weeklyGrid}>
            {weeklySchedule.map((day, index) => {
              const IconComponent = getTypeIcon(day.type);
              return (
                <View key={index} style={styles.dayCard}>
                  <Text style={styles.dayLabel}>{day.day}</Text>
                  <View style={[
                    styles.dayIcon,
                    { backgroundColor: getStatusColor(day.status) + '20' }
                  ]}>
                    <IconComponent size={16} color={getStatusColor(day.status)} />
                  </View>
                  <Text style={[styles.dayType, { color: getStatusColor(day.status) }]}>
                    {day.type}
                  </Text>
                  <Text style={styles.dayFocus}>{day.focus}</Text>
                </View>
              );
            })}
          </View>
        </Card>

        {/* Recommendations */}
        <Card style={styles.recommendationsCard}>
          <Text style={styles.sectionTitle}>Personalized Recommendations</Text>
          
          <View style={styles.recommendation}>
            <View style={styles.recommendationIcon}>
              <Shield size={20} color="#F59E0B" />
            </View>
            <View style={styles.recommendationContent}>
              <Text style={styles.recommendationTitle}>Focus on Ankle Stability</Text>
              <Text style={styles.recommendationText}>
                Based on your injury history, prioritize ankle strengthening exercises this week.
              </Text>
            </View>
          </View>

          <View style={styles.recommendation}>
            <View style={styles.recommendationIcon}>
              <Activity size={20} color="#3B82F6" />
            </View>
            <View style={styles.recommendationContent}>
              <Text style={styles.recommendationTitle}>Increase Recovery Time</Text>
              <Text style={styles.recommendationText}>
                Your training load is high. Consider adding an extra recovery session.
              </Text>
            </View>
          </View>

          <View style={styles.recommendation}>
            <View style={styles.recommendationIcon}>
              <Trophy size={20} color="#10B981" />
            </View>
            <View style={styles.recommendationContent}>
              <Text style={styles.recommendationTitle}>Great Progress!</Text>
              <Text style={styles.recommendationText}>
                You're 18% through your program with excellent consistency.
              </Text>
            </View>
          </View>
        </Card>

        {/* Quick Actions */}
        <View style={styles.quickActions}>
          <TouchableOpacity style={styles.actionCard}>
            <View style={styles.actionIcon}>
              <Target size={20} color="#3B82F6" />
            </View>
            <Text style={styles.actionText}>Modify Plan</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.actionCard}>
            <View style={styles.actionIcon}>
              <Calendar size={20} color="#10B981" />
            </View>
            <Text style={styles.actionText}>Schedule</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.actionCard}>
            <View style={styles.actionIcon}>
              <Star size={20} color="#F59E0B" />
            </View>
            <Text style={styles.actionText}>Progress</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaWrapper>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#94A3B8',
    marginTop: 8,
    lineHeight: 22,
  },
  profileCard: {
    marginHorizontal: 20,
    backgroundColor: '#1E3A8A20',
    borderWidth: 1,
    borderColor: '#3B82F6',
  },
  profileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  profileIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#3B82F6',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  profileInfo: {
    flex: 1,
  },
  profileTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  profileDetails: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#94A3B8',
  },
  profileTags: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  riskTag: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: '#F59E0B20',
    borderWidth: 1,
    borderColor: '#F59E0B',
  },
  riskTagText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#F59E0B',
  },
  programCard: {
    marginHorizontal: 20,
  },
  programHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 20,
  },
  programIcon: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#1E3A8A20',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
    borderWidth: 2,
    borderColor: '#3B82F6',
  },
  programInfo: {
    flex: 1,
  },
  programTitle: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginBottom: 6,
  },
  programDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#94A3B8',
    lineHeight: 20,
  },
  programStats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 24,
    paddingVertical: 16,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: '#374151',
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#94A3B8',
    textAlign: 'center',
  },
  phases: {
    gap: 16,
  },
  phasesTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  phaseItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  phaseIndicator: {
    width: 4,
    height: 40,
    borderRadius: 2,
    marginRight: 16,
  },
  phaseContent: {
    flex: 1,
  },
  phaseName: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
    marginBottom: 2,
  },
  phaseWeeks: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#3B82F6',
    marginBottom: 2,
  },
  phaseFocus: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#94A3B8',
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
    marginBottom: 16,
  },
  progressGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
  },
  progressItem: {
    flex: 1,
    minWidth: '45%',
    alignItems: 'center',
    padding: 16,
    borderRadius: 12,
    backgroundColor: '#374151',
  },
  progressValue: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    marginBottom: 4,
  },
  progressLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#94A3B8',
    textAlign: 'center',
  },
  workoutCard: {
    marginHorizontal: 20,
    backgroundColor: '#10B98120',
    borderWidth: 1,
    borderColor: '#10B981',
  },
  workoutHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  workoutInfo: {
    flex: 1,
  },
  workoutTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  workoutPhase: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#10B981',
    marginBottom: 8,
  },
  workoutMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  workoutDuration: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#94A3B8',
  },
  playButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#10B981',
    alignItems: 'center',
    justifyContent: 'center',
  },
  workoutProgress: {
    marginBottom: 16,
  },
  progressBar: {
    height: 6,
    backgroundColor: '#374151',
    borderRadius: 3,
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#10B981',
    borderRadius: 3,
  },
  progressText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#94A3B8',
  },
  exerciseList: {
    gap: 12,
    marginBottom: 20,
  },
  exerciseItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  exerciseCheck: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#374151',
    marginRight: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  exerciseCheckCompleted: {
    borderColor: '#10B981',
    backgroundColor: '#10B98120',
  },
  exerciseInfo: {
    flex: 1,
  },
  exerciseName: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#FFFFFF',
    marginBottom: 2,
  },
  exerciseNameCompleted: {
    color: '#94A3B8',
    textDecorationLine: 'line-through',
  },
  exerciseDuration: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#94A3B8',
  },
  moreExercises: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#3B82F6',
    textAlign: 'center',
    marginTop: 8,
  },
  continueButton: {
    backgroundColor: '#10B981',
  },
  scheduleHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  weeklyGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  dayCard: {
    flex: 1,
    minWidth: '13%',
    alignItems: 'center',
    padding: 12,
    borderRadius: 12,
    backgroundColor: '#374151',
  },
  dayLabel: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  dayIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  dayType: {
    fontSize: 10,
    fontFamily: 'Inter-SemiBold',
    marginBottom: 4,
  },
  dayFocus: {
    fontSize: 8,
    fontFamily: 'Inter-Regular',
    color: '#94A3B8',
    textAlign: 'center',
  },
  recommendationsCard: {
    marginHorizontal: 20,
  },
  recommendation: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  recommendationIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#374151',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  recommendationContent: {
    flex: 1,
  },
  recommendationTitle: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  recommendationText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#94A3B8',
    lineHeight: 18,
  },
  quickActions: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    gap: 12,
    marginBottom: 32,
  },
  actionCard: {
    flex: 1,
    alignItems: 'center',
    padding: 16,
    borderRadius: 16,
    backgroundColor: '#1E293B',
    borderWidth: 1,
    borderColor: '#374151',
  },
  actionIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#374151',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  actionText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#94A3B8',
    textAlign: 'center',
  },
});