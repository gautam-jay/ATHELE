import { ScrollView, View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import SafeAreaWrapper from '@/components/SafeAreaWrapper';
import Card from '@/components/Card';
import Button from '@/components/Button';
import { 
  BookOpen, 
  Video, 
  FileText, 
  Clock, 
  Star,
  Bookmark,
  Share,
  ChevronRight,
  TrendingUp,
  Users
} from 'lucide-react-native';

export default function InsightsScreen() {
  const featuredArticles = [
    {
      id: 1,
      title: '5 Pre-Training Habits That Prevent ACL Injuries',
      author: 'Dr. Sarah Johnson',
      readTime: '5 min read',
      category: 'Prevention',
      image: 'https://images.pexels.com/photos/3823488/pexels-photo-3823488.jpeg?auto=compress&cs=tinysrgb&w=400',
      rating: 4.8,
      saved: true,
    },
    {
      id: 2,
      title: 'The Science of Warm-Up: Why 15 Minutes Can Save Your Season',
      author: 'Coach Michael Thompson',
      readTime: '7 min read',
      category: 'Training',
      image: 'https://images.pexels.com/photos/4056723/pexels-photo-4056723.jpeg?auto=compress&cs=tinysrgb&w=400',
      rating: 4.9,
      saved: false,
    },
  ];

  const categories = [
    { id: 1, name: 'Prevention', count: 24, color: '#2563EB' },
    { id: 2, name: 'Recovery', count: 18, color: '#10B981' },
    { id: 3, name: 'Nutrition', count: 12, color: '#F59E0B' },
    { id: 4, name: 'Psychology', count: 8, color: '#EC4899' },
  ];

  const videos = [
    {
      id: 1,
      title: 'Dynamic Warm-Up Routine for Soccer Players',
      duration: '12:30',
      views: '24K',
      thumbnail: 'https://images.pexels.com/photos/3764011/pexels-photo-3764011.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      id: 2,
      title: 'Ankle Stability Exercises for Basketball',
      duration: '8:45',
      views: '18K',
      thumbnail: 'https://images.pexels.com/photos/3764011/pexels-photo-3764011.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
  ];

  const experts = [
    {
      id: 1,
      name: 'Dr. Sarah Johnson',
      title: 'Sports Medicine Physician',
      specialty: 'ACL Prevention',
      articles: 12,
      avatar: 'https://images.pexels.com/photos/5215024/pexels-photo-5215024.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      id: 2,
      name: 'Coach Michael Thompson',
      title: 'Performance Coach',
      specialty: 'Training Optimization',
      articles: 8,
      avatar: 'https://images.pexels.com/photos/5215024/pexels-photo-5215024.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
  ];

  return (
    <SafeAreaWrapper>
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Expert Insights</Text>
          <Text style={styles.subtitle}>
            Learn from sports medicine experts and elite coaches
          </Text>
        </View>

        {/* Featured Articles */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Featured Articles</Text>
          {featuredArticles.map((article) => (
            <Card key={article.id} style={styles.articleCard}>
              <TouchableOpacity style={styles.articleContent}>
                <Image source={{ uri: article.image }} style={styles.articleImage} />
                <View style={styles.articleInfo}>
                  <View style={styles.articleHeader}>
                    <Text style={styles.categoryTag}>{article.category}</Text>
                    <TouchableOpacity style={styles.bookmarkButton}>
                      <Bookmark 
                        size={16} 
                        color={article.saved ? '#2563EB' : '#64748B'}
                        fill={article.saved ? '#2563EB' : 'none'}
                      />
                    </TouchableOpacity>
                  </View>
                  <Text style={styles.articleTitle}>{article.title}</Text>
                  <View style={styles.articleMeta}>
                    <Text style={styles.authorText}>{article.author}</Text>
                    <View style={styles.metaSeparator} />
                    <Clock size={12} color="#64748B" />
                    <Text style={styles.readTimeText}>{article.readTime}</Text>
                    <View style={styles.metaSeparator} />
                    <Star size={12} color="#F59E0B" />
                    <Text style={styles.ratingText}>{article.rating}</Text>
                  </View>
                </View>
              </TouchableOpacity>
            </Card>
          ))}
        </View>

        {/* Categories */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Browse by Category</Text>
          <View style={styles.categoriesGrid}>
            {categories.map((category) => (
              <Card key={category.id} style={styles.categoryCard}>
                <TouchableOpacity style={styles.categoryContent}>
                  <View style={[styles.categoryIcon, { backgroundColor: category.color + '20' }]}>
                    <BookOpen size={20} color={category.color} />
                  </View>
                  <Text style={styles.categoryName}>{category.name}</Text>
                  <Text style={styles.categoryCount}>{category.count} articles</Text>
                </TouchableOpacity>
              </Card>
            ))}
          </View>
        </View>

        {/* Video Content */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Video Library</Text>
            <TouchableOpacity>
              <ChevronRight size={20} color="#64748B" />
            </TouchableOpacity>
          </View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.videoList}>
            {videos.map((video, index) => (
              <Card key={video.id} style={[styles.videoCard, { marginLeft: index === 0 ? 20 : 0 }]}>
                <TouchableOpacity style={styles.videoContent}>
                  <View style={styles.videoThumbnail}>
                    <Image source={{ uri: video.thumbnail }} style={styles.thumbnailImage} />
                    <View style={styles.playButton}>
                      <Video size={20} color="#FFFFFF" />
                    </View>
                    <View style={styles.durationBadge}>
                      <Text style={styles.durationText}>{video.duration}</Text>
                    </View>
                  </View>
                  <View style={styles.videoInfo}>
                    <Text style={styles.videoTitle}>{video.title}</Text>
                    <View style={styles.videoMeta}>
                      <TrendingUp size={12} color="#64748B" />
                      <Text style={styles.viewsText}>{video.views} views</Text>
                    </View>
                  </View>
                </TouchableOpacity>
              </Card>
            ))}
          </ScrollView>
        </View>

        {/* Expert Profiles */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Featured Experts</Text>
          {experts.map((expert) => (
            <Card key={expert.id} style={styles.expertCard}>
              <TouchableOpacity style={styles.expertContent}>
                <Image source={{ uri: expert.avatar }} style={styles.expertAvatar} />
                <View style={styles.expertInfo}>
                  <Text style={styles.expertName}>{expert.name}</Text>
                  <Text style={styles.expertTitle}>{expert.title}</Text>
                  <Text style={styles.expertSpecialty}>Specialty: {expert.specialty}</Text>
                  <View style={styles.expertMeta}>
                    <FileText size={12} color="#64748B" />
                    <Text style={styles.articlesCount}>{expert.articles} articles</Text>
                  </View>
                </View>
                <ChevronRight size={20} color="#64748B" />
              </TouchableOpacity>
            </Card>
          ))}
        </View>

        {/* Community Insights */}
        <Card style={styles.communityCard}>
          <View style={styles.communityHeader}>
            <View style={styles.communityIcon}>
              <Users size={24} color="#2563EB" />
            </View>
            <View style={styles.communityInfo}>
              <Text style={styles.communityTitle}>Community Insights</Text>
              <Text style={styles.communityDescription}>
                Share experiences and learn from fellow athletes
              </Text>
            </View>
          </View>
          <Button
            title="Join Discussion"
            onPress={() => {}}
            variant="outline"
            style={styles.communityButton}
          />
        </Card>
      </ScrollView>
    </SafeAreaWrapper>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#0F172A',
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginTop: 8,
    lineHeight: 22,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginBottom: 16,
    paddingHorizontal: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
    paddingHorizontal: 20,
  },
  articleCard: {
    marginHorizontal: 20,
    marginBottom: 16,
  },
  articleContent: {
    margin: -20,
    padding: 20,
  },
  articleImage: {
    width: '100%',
    height: 160,
    borderRadius: 8,
    marginBottom: 16,
  },
  articleInfo: {
    flex: 1,
  },
  articleHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  categoryTag: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#2563EB',
    backgroundColor: '#EFF6FF',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  bookmarkButton: {
    padding: 4,
  },
  articleTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginBottom: 8,
    lineHeight: 22,
  },
  articleMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  authorText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
  metaSeparator: {
    width: 1,
    height: 12,
    backgroundColor: '#E2E8F0',
  },
  readTimeText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
  ratingText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
  categoriesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 20,
    gap: 12,
  },
  categoryCard: {
    width: '48%',
    alignItems: 'center',
    padding: 16,
  },
  categoryContent: {
    alignItems: 'center',
  },
  categoryIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  categoryName: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginBottom: 4,
  },
  categoryCount: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
  videoList: {
    paddingBottom: 16,
  },
  videoCard: {
    width: 240,
    marginRight: 16,
    marginBottom: 0,
  },
  videoContent: {
    margin: -20,
    padding: 20,
  },
  videoThumbnail: {
    position: 'relative',
    marginBottom: 12,
  },
  thumbnailImage: {
    width: '100%',
    height: 120,
    borderRadius: 8,
  },
  playButton: {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: [{ translateX: -20 }, { translateY: -20 }],
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  durationBadge: {
    position: 'absolute',
    bottom: 8,
    right: 8,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  durationText: {
    fontSize: 10,
    fontFamily: 'Inter-Medium',
    color: '#FFFFFF',
  },
  videoInfo: {
    flex: 1,
  },
  videoTitle: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginBottom: 4,
    lineHeight: 20,
  },
  videoMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  viewsText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
  expertCard: {
    marginHorizontal: 20,
    marginBottom: 12,
  },
  expertContent: {
    flexDirection: 'row',
    alignItems: 'center',
    margin: -20,
    padding: 20,
  },
  expertAvatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
    marginRight: 16,
  },
  expertInfo: {
    flex: 1,
  },
  expertName: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginBottom: 4,
  },
  expertTitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginBottom: 4,
  },
  expertSpecialty: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#2563EB',
    marginBottom: 4,
  },
  expertMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  articlesCount: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
  communityCard: {
    marginHorizontal: 20,
    marginBottom: 32,
    backgroundColor: '#F0F9FF',
    borderWidth: 1,
    borderColor: '#BAE6FD',
  },
  communityHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  communityIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#EFF6FF',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  communityInfo: {
    flex: 1,
  },
  communityTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginBottom: 4,
  },
  communityDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    lineHeight: 20,
  },
  communityButton: {
    alignSelf: 'flex-start',
  },
});