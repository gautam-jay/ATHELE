import { ScrollView, View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import SafeAreaWrapper from '@/components/SafeAreaWrapper';
import Card from '@/components/Card';
import Button from '@/components/Button';
import RiskIndicator from '@/components/RiskIndicator';
import { Activity, Heart, Moon, Droplets, Zap, Plus, TrendingUp, Calendar, CircleAlert as AlertCircle } from 'lucide-react-native';

export default function MonitorScreen() {
  const todayMetrics = [
    {
      id: 1,
      title: 'Sleep Quality',
      value: '7.5h',
      status: 'good',
      icon: Moon,
      color: '#6366F1',
      trend: '+0.5h',
    },
    {
      id: 2,
      title: 'Training Load',
      value: 'High',
      status: 'warning',
      icon: Zap,
      color: '#F59E0B',
      trend: '+15%',
    },
    {
      id: 3,
      title: 'Hydration',
      value: '2.1L',
      status: 'good',
      icon: Droplets,
      color: '#0891B2',
      trend: 'On track',
    },
    {
      id: 4,
      title: 'Soreness',
      value: '3/10',
      status: 'good',
      icon: Heart,
      color: '#10B981',
      trend: '-1 from yesterday',
    },
  ];

  const weeklyTrends = [
    { day: 'Mon', risk: 'low', load: 60 },
    { day: 'Tue', risk: 'low', load: 75 },
    { day: 'Wed', risk: 'medium', load: 90 },
    { day: 'Thu', risk: 'medium', load: 85 },
    { day: 'Fri', risk: 'high', load: 95 },
    { day: 'Sat', risk: 'medium', load: 70 },
    { day: 'Sun', risk: 'low', load: 40 },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'good':
        return '#10B981';
      case 'warning':
        return '#F59E0B';
      case 'danger':
        return '#EF4444';
      default:
        return '#64748B';
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low':
        return '#10B981';
      case 'medium':
        return '#F59E0B';
      case 'high':
        return '#EF4444';
      default:
        return '#64748B';
    }
  };

  return (
    <SafeAreaWrapper>
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Health Monitor</Text>
          <Text style={styles.subtitle}>
            Track your daily metrics to optimize injury prevention
          </Text>
        </View>

        {/* Current Risk Status */}
        <Card style={styles.riskCard}>
          <View style={styles.riskHeader}>
            <View style={styles.riskIcon}>
              <AlertCircle size={24} color="#F59E0B" />
            </View>
            <View style={styles.riskContent}>
              <Text style={styles.riskTitle}>Today's Risk Level</Text>
              <RiskIndicator risk="medium" />
            </View>
          </View>
          <Text style={styles.riskDescription}>
            Elevated training load detected. Consider reducing intensity today.
          </Text>
        </Card>

        {/* Today's Metrics */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Today's Metrics</Text>
          <View style={styles.metricsGrid}>
            {todayMetrics.map((metric) => {
              const IconComponent = metric.icon;
              return (
                <Card key={metric.id} style={styles.metricCard}>
                  <View style={styles.metricHeader}>
                    <View style={[styles.metricIcon, { backgroundColor: metric.color + '20' }]}>
                      <IconComponent size={20} color={metric.color} />
                    </View>
                    <View 
                      style={[
                        styles.statusIndicator, 
                        { backgroundColor: getStatusColor(metric.status) }
                      ]} 
                    />
                  </View>
                  <Text style={styles.metricValue}>{metric.value}</Text>
                  <Text style={styles.metricTitle}>{metric.title}</Text>
                  <Text style={[styles.metricTrend, { color: getStatusColor(metric.status) }]}>
                    {metric.trend}
                  </Text>
                </Card>
              );
            })}
          </View>
        </View>

        {/* Weekly Trends */}
        <Card style={styles.trendsCard}>
          <View style={styles.trendsHeader}>
            <Text style={styles.trendsTitle}>Weekly Risk Trends</Text>
            <TouchableOpacity>
              <TrendingUp size={20} color="#64748B" />
            </TouchableOpacity>
          </View>
          <View style={styles.weeklyChart}>
            {weeklyTrends.map((day, index) => (
              <View key={index} style={styles.dayColumn}>
                <View style={styles.barContainer}>
                  <View 
                    style={[
                      styles.loadBar, 
                      { 
                        height: `${day.load}%`,
                        backgroundColor: getRiskColor(day.risk)
                      }
                    ]} 
                  />
                </View>
                <Text style={styles.dayLabel}>{day.day}</Text>
              </View>
            ))}
          </View>
        </Card>

        {/* Quick Actions */}
        <View style={styles.quickActions}>
          <Button
            title="Log Symptoms"
            onPress={() => {}}
            variant="outline"
            style={styles.actionButton}
          />
          <Button
            title="Add Entry"
            onPress={() => {}}
            style={styles.actionButton}
          />
        </View>

        {/* Recent Entries */}
        <Card>
          <View style={styles.entriesHeader}>
            <Text style={styles.entriesTitle}>Recent Entries</Text>
            <TouchableOpacity>
              <Calendar size={20} color="#64748B" />
            </TouchableOpacity>
          </View>
          <View style={styles.entryList}>
            <View style={styles.entryItem}>
              <View style={styles.entryTime}>
                <Text style={styles.entryTimeText}>Today</Text>
                <Text style={styles.entryTimeSubtext}>8:30 AM</Text>
              </View>
              <View style={styles.entryContent}>
                <Text style={styles.entryTitle}>Morning Check-in</Text>
                <Text style={styles.entryDescription}>
                  Feeling good, slight soreness in left calf
                </Text>
              </View>
            </View>
            <View style={styles.entryItem}>
              <View style={styles.entryTime}>
                <Text style={styles.entryTimeText}>Yesterday</Text>
                <Text style={styles.entryTimeSubtext}>9:15 PM</Text>
              </View>
              <View style={styles.entryContent}>
                <Text style={styles.entryTitle}>Post-Training</Text>
                <Text style={styles.entryDescription}>
                  Intense session, hydrated well
                </Text>
              </View>
            </View>
          </View>
        </Card>
      </ScrollView>

      {/* Floating Action Button */}
      <TouchableOpacity style={styles.fab}>
        <Plus size={24} color="#FFFFFF" />
      </TouchableOpacity>
    </SafeAreaWrapper>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#0F172A',
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginTop: 8,
    lineHeight: 22,
  },
  riskCard: {
    marginHorizontal: 20,
    backgroundColor: '#FFFBEB',
    borderWidth: 1,
    borderColor: '#FED7AA',
  },
  riskHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  riskIcon: {
    marginRight: 12,
  },
  riskContent: {
    flex: 1,
  },
  riskTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginBottom: 4,
  },
  riskDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    lineHeight: 20,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginBottom: 16,
    paddingHorizontal: 20,
  },
  metricsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 20,
    gap: 12,
  },
  metricCard: {
    width: '48%',
    alignItems: 'center',
    padding: 16,
  },
  metricHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
    marginBottom: 12,
  },
  metricIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  statusIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  metricValue: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#0F172A',
    marginBottom: 4,
  },
  metricTitle: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#64748B',
    marginBottom: 4,
    textAlign: 'center',
  },
  metricTrend: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    textAlign: 'center',
  },
  trendsCard: {
    marginHorizontal: 20,
    marginBottom: 24,
  },
  trendsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  trendsTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
  },
  weeklyChart: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    height: 120,
    gap: 8,
  },
  dayColumn: {
    flex: 1,
    alignItems: 'center',
  },
  barContainer: {
    height: 80,
    width: '100%',
    backgroundColor: '#F1F5F9',
    borderRadius: 4,
    marginBottom: 8,
    justifyContent: 'flex-end',
  },
  loadBar: {
    width: '100%',
    borderRadius: 4,
    minHeight: 4,
  },
  dayLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
  quickActions: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    gap: 12,
    marginBottom: 24,
  },
  actionButton: {
    flex: 1,
  },
  entriesHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  entriesTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
  },
  entryList: {
    gap: 16,
  },
  entryItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  entryTime: {
    width: 80,
    marginRight: 16,
  },
  entryTimeText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
  },
  entryTimeSubtext: {
    fontSize: 10,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
  entryContent: {
    flex: 1,
  },
  entryTitle: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginBottom: 4,
  },
  entryDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    lineHeight: 20,
  },
  fab: {
    position: 'absolute',
    bottom: 20,
    right: 20,
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#2563EB',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
});