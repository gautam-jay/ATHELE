import { ScrollView, View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import SafeAreaWrapper from '@/components/SafeAreaWrapper';
import Card from '@/components/Card';
import Button from '@/components/Button';
import RiskIndicator from '@/components/RiskIndicator';
import { Bell, Activity, Target, TrendingUp, Calendar, ChevronRight, Shield, TriangleAlert as AlertTriangle } from 'lucide-react-native';

export default function HomeScreen() {
  const todayRisk = 'medium';
  const streakDays = 14;
  const completedToday = 2;
  const totalToday = 3;

  return (
    <SafeAreaWrapper>
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Good morning, Alex!</Text>
            <Text style={styles.subtitle}>Ready to stay injury-free today?</Text>
          </View>
          <TouchableOpacity style={styles.notificationButton}>
            <Bell size={24} color="#64748B" />
          </TouchableOpacity>
        </View>

        {/* Daily Risk Status */}
        <Card style={styles.riskCard}>
          <View style={styles.riskHeader}>
            <View style={styles.riskIcon}>
              {todayRisk === 'low' ? (
                <Shield size={24} color="#10B981" />
              ) : (
                <AlertTriangle size={24} color="#F59E0B" />
              )}
            </View>
            <View style={styles.riskContent}>
              <Text style={styles.riskTitle}>Today's Injury Risk</Text>
              <RiskIndicator risk={todayRisk} />
            </View>
          </View>
          <Text style={styles.riskDescription}>
            Your sleep quality was good, but training load is elevated. Consider extra warm-up today.
          </Text>
        </Card>

        {/* Quick Stats */}
        <View style={styles.statsContainer}>
          <Card style={styles.statCard}>
            <View style={styles.statHeader}>
              <Activity size={20} color="#2563EB" />
              <Text style={styles.statValue}>{streakDays}</Text>
            </View>
            <Text style={styles.statLabel}>Day Streak</Text>
          </Card>
          <Card style={styles.statCard}>
            <View style={styles.statHeader}>
              <Target size={20} color="#10B981" />
              <Text style={styles.statValue}>{completedToday}/{totalToday}</Text>
            </View>
            <Text style={styles.statLabel}>Today's Goals</Text>
          </Card>
        </View>

        {/* Today's Program */}
        <Card>
          <View style={styles.programHeader}>
            <Text style={styles.programTitle}>Today's Prevention Program</Text>
            <TouchableOpacity>
              <ChevronRight size={20} color="#64748B" />
            </TouchableOpacity>
          </View>
          <Text style={styles.programSubtitle}>Soccer - Midfielder Focus</Text>
          
          <View style={styles.programTasks}>
            <View style={styles.taskItem}>
              <View style={[styles.taskCheck, styles.taskCompleted]} />
              <Text style={[styles.taskText, styles.taskCompletedText]}>
                Dynamic Warm-up (15 min)
              </Text>
            </View>
            <View style={styles.taskItem}>
              <View style={[styles.taskCheck, styles.taskCompleted]} />
              <Text style={[styles.taskText, styles.taskCompletedText]}>
                Ankle Mobility Routine (10 min)
              </Text>
            </View>
            <View style={styles.taskItem}>
              <View style={styles.taskCheck} />
              <Text style={styles.taskText}>
                Core Stability Training (20 min)
              </Text>
            </View>
          </View>

          <Button
            title="Start Next Exercise"
            onPress={() => {}}
            style={styles.startButton}
          />
        </Card>

        {/* Quick Actions */}
        <View style={styles.quickActions}>
          <TouchableOpacity style={styles.actionButton}>
            <View style={styles.actionIcon}>
              <Activity size={20} color="#2563EB" />
            </View>
            <Text style={styles.actionText}>Log Symptoms</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionButton}>
            <View style={styles.actionIcon}>
              <TrendingUp size={20} color="#0891B2" />
            </View>
            <Text style={styles.actionText}>View Progress</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionButton}>
            <View style={styles.actionIcon}>
              <Calendar size={20} color="#EA580C" />
            </View>
            <Text style={styles.actionText}>Schedule</Text>
          </TouchableOpacity>
        </View>

        {/* Recent Insights */}
        <Card>
          <Text style={styles.insightsTitle}>Latest Insights</Text>
          <View style={styles.insightItem}>
            <Image 
              source={{ uri: 'https://images.pexels.com/photos/3823488/pexels-photo-3823488.jpeg?auto=compress&cs=tinysrgb&w=400' }}
              style={styles.insightImage}
            />
            <View style={styles.insightContent}>
              <Text style={styles.insightTitle}>5 Pre-Training Habits That Prevent ACL Injuries</Text>
              <Text style={styles.insightMeta}>Dr. Sarah Johnson • 3 min read</Text>
            </View>
          </View>
        </Card>
      </ScrollView>
    </SafeAreaWrapper>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  greeting: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#0F172A',
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginTop: 4,
  },
  notificationButton: {
    padding: 8,
  },
  riskCard: {
    marginHorizontal: 20,
    backgroundColor: '#FFFBEB',
    borderWidth: 1,
    borderColor: '#FED7AA',
  },
  riskHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  riskIcon: {
    marginRight: 12,
  },
  riskContent: {
    flex: 1,
  },
  riskTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginBottom: 4,
  },
  riskDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    lineHeight: 20,
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    gap: 12,
  },
  statCard: {
    flex: 1,
    alignItems: 'center',
    padding: 16,
  },
  statHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  statValue: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#0F172A',
    marginLeft: 8,
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#64748B',
    textAlign: 'center',
  },
  programHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  programTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
  },
  programSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginBottom: 16,
  },
  programTasks: {
    marginBottom: 20,
  },
  taskItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  taskCheck: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#E2E8F0',
    marginRight: 12,
  },
  taskCompleted: {
    backgroundColor: '#10B981',
    borderColor: '#10B981',
  },
  taskText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#0F172A',
    flex: 1,
  },
  taskCompletedText: {
    color: '#64748B',
    textDecorationLine: 'line-through',
  },
  startButton: {
    marginTop: 8,
  },
  quickActions: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  actionButton: {
    alignItems: 'center',
    flex: 1,
  },
  actionIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#F1F5F9',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  actionText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#64748B',
    textAlign: 'center',
  },
  insightsTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginBottom: 16,
  },
  insightItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  insightImage: {
    width: 60,
    height: 60,
    borderRadius: 8,
    marginRight: 12,
  },
  insightContent: {
    flex: 1,
  },
  insightTitle: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginBottom: 4,
    lineHeight: 20,
  },
  insightMeta: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
});