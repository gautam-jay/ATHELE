import { useState } from 'react';
import { ScrollView, View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { router } from 'expo-router';
import SafeAreaWrapper from '@/components/SafeAreaWrapper';
import Card from '@/components/Card';
import Button from '@/components/Button';
import { ArrowLeft, Play, Pause, RotateCcw, CircleCheck as CheckCircle, Clock, Target, Info } from 'lucide-react-native';

export default function WorkoutScreen() {
  const [currentExercise, setCurrentExercise] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [timer, setTimer] = useState(0);
  const [completedExercises, setCompletedExercises] = useState<number[]>([]);

  const workout = {
    title: 'Dynamic Warm-Up & Ankle Stability',
    phase: 'Foundation Phase - Week 2',
    totalDuration: '20 min',
    difficulty: 'Beginner',
    focus: 'Ankle Stability & Movement Prep',
    exercises: [
      {
        id: 1,
        name: 'Dynamic Leg Swings',
        duration: 120,
        sets: '2 sets',
        reps: '10 each direction',
        description: 'Stand next to a wall for support. Swing your leg forward and backward in a controlled motion.',
        tips: 'Keep your core engaged and maintain balance',
        image: 'https://images.pexels.com/photos/4056723/pexels-photo-4056723.jpeg?auto=compress&cs=tinysrgb&w=400',
        targetMuscles: ['Hip Flexors', 'Hamstrings', 'Glutes']
      },
      {
        id: 2,
        name: 'Single-Leg Balance',
        duration: 180,
        sets: '3 sets',
        reps: '30 seconds each leg',
        description: 'Stand on one leg with eyes closed. Focus on maintaining balance without touching the ground.',
        tips: 'Start with eyes open, progress to eyes closed',
        image: 'https://images.pexels.com/photos/4056532/pexels-photo-4056532.jpeg?auto=compress&cs=tinysrgb&w=400',
        targetMuscles: ['Ankle Stabilizers', 'Core', 'Proprioceptors']
      },
      {
        id: 3,
        name: 'Ankle Circles & Flexion',
        duration: 120,
        sets: '2 sets',
        reps: '10 circles each direction',
        description: 'Sit or stand and rotate your ankle in slow, controlled circles. Then flex and point your foot.',
        tips: 'Make the circles as large as possible',
        image: 'https://images.pexels.com/photos/4056723/pexels-photo-4056723.jpeg?auto=compress&cs=tinysrgb&w=400',
        targetMuscles: ['Ankle Flexors', 'Calf Muscles', 'Shin Muscles']
      },
      {
        id: 4,
        name: 'Lateral Lunges',
        duration: 180,
        sets: '2 sets',
        reps: '8 each side',
        description: 'Step wide to one side, lowering into a lunge while keeping the other leg straight.',
        tips: 'Keep your chest up and weight in your heels',
        image: 'https://images.pexels.com/photos/4056532/pexels-photo-4056532.jpeg?auto=compress&cs=tinysrgb&w=400',
        targetMuscles: ['Adductors', 'Glutes', 'Quadriceps']
      },
      {
        id: 5,
        name: 'Calf Raises Progression',
        duration: 180,
        sets: '3 sets',
        reps: '12 reps',
        description: 'Rise up onto your toes, hold briefly, then lower slowly. Progress to single-leg raises.',
        tips: 'Control the descent for maximum benefit',
        image: 'https://images.pexels.com/photos/4056723/pexels-photo-4056723.jpeg?auto=compress&cs=tinysrgb&w=400',
        targetMuscles: ['Calves', 'Ankle Stabilizers', 'Achilles Tendon']
      },
      {
        id: 6,
        name: 'Cool-down Stretches',
        duration: 420,
        sets: '1 set',
        reps: 'Hold 30 seconds each',
        description: 'Gentle stretches for calves, ankles, and hip flexors to promote recovery.',
        tips: 'Breathe deeply and relax into each stretch',
        image: 'https://images.pexels.com/photos/4056532/pexels-photo-4056532.jpeg?auto=compress&cs=tinysrgb&w=400',
        targetMuscles: ['Calves', 'Hip Flexors', 'Ankles']
      }
    ]
  };

  const currentExerciseData = workout.exercises[currentExercise];
  const progressPercentage = ((currentExercise + 1) / workout.exercises.length) * 100;

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handleNext = () => {
    if (currentExercise < workout.exercises.length - 1) {
      setCurrentExercise(prev => prev + 1);
      setTimer(0);
      setIsPlaying(false);
    }
  };

  const handlePrevious = () => {
    if (currentExercise > 0) {
      setCurrentExercise(prev => prev - 1);
      setTimer(0);
      setIsPlaying(false);
    }
  };

  const handleComplete = () => {
    if (!completedExercises.includes(currentExerciseData.id)) {
      setCompletedExercises(prev => [...prev, currentExerciseData.id]);
    }
    handleNext();
  };

  const handleFinishWorkout = () => {
    router.back();
  };

  return (
    <SafeAreaWrapper>
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity 
            style={styles.backButton}
            onPress={() => router.back()}
          >
            <ArrowLeft size={24} color="#94A3B8" />
          </TouchableOpacity>
          <View style={styles.headerInfo}>
            <Text style={styles.workoutTitle}>{workout.title}</Text>
            <Text style={styles.workoutPhase}>{workout.phase}</Text>
          </View>
        </View>

        {/* Progress Bar */}
        <View style={styles.progressSection}>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { width: `${progressPercentage}%` }]} />
          </View>
          <Text style={styles.progressText}>
            Exercise {currentExercise + 1} of {workout.exercises.length}
          </Text>
        </View>

        {/* Current Exercise */}
        <Card style={styles.exerciseCard}>
          <Image 
            source={{ uri: currentExerciseData.image }} 
            style={styles.exerciseImage}
          />
          
          <View style={styles.exerciseHeader}>
            <Text style={styles.exerciseName}>{currentExerciseData.name}</Text>
            <View style={styles.exerciseMeta}>
              <View style={styles.metaItem}>
                <Clock size={16} color="#3B82F6" />
                <Text style={styles.metaText}>{formatTime(currentExerciseData.duration)}</Text>
              </View>
              <View style={styles.metaItem}>
                <Target size={16} color="#10B981" />
                <Text style={styles.metaText}>{currentExerciseData.sets}</Text>
              </View>
            </View>
          </View>

          <Text style={styles.exerciseReps}>{currentExerciseData.reps}</Text>
          <Text style={styles.exerciseDescription}>{currentExerciseData.description}</Text>

          {/* Timer Display */}
          <View style={styles.timerSection}>
            <Text style={styles.timerDisplay}>{formatTime(timer)}</Text>
            <View style={styles.timerControls}>
              <TouchableOpacity style={styles.timerButton} onPress={() => setTimer(0)}>
                <RotateCcw size={20} color="#94A3B8" />
              </TouchableOpacity>
              <TouchableOpacity style={styles.playButton} onPress={handlePlayPause}>
                {isPlaying ? (
                  <Pause size={24} color="#FFFFFF" />
                ) : (
                  <Play size={24} color="#FFFFFF" />
                )}
              </TouchableOpacity>
            </View>
          </View>

          {/* Exercise Tips */}
          <View style={styles.tipsSection}>
            <View style={styles.tipsHeader}>
              <Info size={16} color="#F59E0B" />
              <Text style={styles.tipsTitle}>Pro Tip</Text>
            </View>
            <Text style={styles.tipsText}>{currentExerciseData.tips}</Text>
          </View>

          {/* Target Muscles */}
          <View style={styles.musclesSection}>
            <Text style={styles.musclesTitle}>Target Muscles</Text>
            <View style={styles.musclesTags}>
              {currentExerciseData.targetMuscles.map((muscle, index) => (
                <View key={index} style={styles.muscleTag}>
                  <Text style={styles.muscleTagText}>{muscle}</Text>
                </View>
              ))}
            </View>
          </View>
        </Card>

        {/* Exercise Navigation */}
        <View style={styles.navigation}>
          <Button
            title="Previous"
            onPress={handlePrevious}
            variant="outline"
            disabled={currentExercise === 0}
            style={[styles.navButton, { opacity: currentExercise === 0 ? 0.5 : 1 }]}
          />
          
          <Button
            title="Complete Exercise"
            onPress={handleComplete}
            style={styles.completeButton}
          />
          
          {currentExercise === workout.exercises.length - 1 ? (
            <Button
              title="Finish"
              onPress={handleFinishWorkout}
              variant="secondary"
              style={styles.navButton}
            />
          ) : (
            <Button
              title="Skip"
              onPress={handleNext}
              variant="outline"
              style={styles.navButton}
            />
          )}
        </View>

        {/* Exercise List */}
        <Card>
          <Text style={styles.listTitle}>Exercise Overview</Text>
          <View style={styles.exerciseList}>
            {workout.exercises.map((exercise, index) => (
              <TouchableOpacity
                key={exercise.id}
                style={[
                  styles.exerciseListItem,
                  index === currentExercise && styles.exerciseListItemActive,
                  completedExercises.includes(exercise.id) && styles.exerciseListItemCompleted
                ]}
                onPress={() => setCurrentExercise(index)}
              >
                <View style={styles.exerciseListNumber}>
                  {completedExercises.includes(exercise.id) ? (
                    <CheckCircle size={20} color="#10B981" />
                  ) : (
                    <Text style={[
                      styles.exerciseNumber,
                      index === currentExercise && styles.exerciseNumberActive
                    ]}>
                      {index + 1}
                    </Text>
                  )}
                </View>
                <View style={styles.exerciseListInfo}>
                  <Text style={[
                    styles.exerciseListName,
                    index === currentExercise && styles.exerciseListNameActive,
                    completedExercises.includes(exercise.id) && styles.exerciseListNameCompleted
                  ]}>
                    {exercise.name}
                  </Text>
                  <Text style={styles.exerciseListDuration}>
                    {formatTime(exercise.duration)} • {exercise.sets}
                  </Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </Card>
      </ScrollView>
    </SafeAreaWrapper>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  backButton: {
    padding: 8,
    marginRight: 12,
  },
  headerInfo: {
    flex: 1,
  },
  workoutTitle: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
  },
  workoutPhase: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#3B82F6',
    marginTop: 2,
  },
  progressSection: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  progressBar: {
    height: 6,
    backgroundColor: '#374151',
    borderRadius: 3,
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#3B82F6',
    borderRadius: 3,
  },
  progressText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#94A3B8',
    textAlign: 'center',
  },
  exerciseCard: {
    marginHorizontal: 20,
    marginBottom: 20,
  },
  exerciseImage: {
    width: '100%',
    height: 200,
    borderRadius: 12,
    marginBottom: 16,
  },
  exerciseHeader: {
    marginBottom: 12,
  },
  exerciseName: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  exerciseMeta: {
    flexDirection: 'row',
    gap: 16,
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  metaText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#94A3B8',
  },
  exerciseReps: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#3B82F6',
    marginBottom: 12,
  },
  exerciseDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#94A3B8',
    lineHeight: 20,
    marginBottom: 20,
  },
  timerSection: {
    alignItems: 'center',
    marginBottom: 20,
    paddingVertical: 20,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: '#374151',
  },
  timerDisplay: {
    fontSize: 48,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginBottom: 16,
  },
  timerControls: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 20,
  },
  timerButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#374151',
    alignItems: 'center',
    justifyContent: 'center',
  },
  playButton: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: '#3B82F6',
    alignItems: 'center',
    justifyContent: 'center',
  },
  tipsSection: {
    marginBottom: 20,
    padding: 16,
    borderRadius: 12,
    backgroundColor: '#F59E0B20',
    borderWidth: 1,
    borderColor: '#F59E0B',
  },
  tipsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
    gap: 8,
  },
  tipsTitle: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#F59E0B',
  },
  tipsText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#FFFFFF',
    lineHeight: 20,
  },
  musclesSection: {
    marginBottom: 20,
  },
  musclesTitle: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
    marginBottom: 12,
  },
  musclesTags: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  muscleTag: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: '#10B98120',
    borderWidth: 1,
    borderColor: '#10B981',
  },
  muscleTagText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#10B981',
  },
  navigation: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    gap: 12,
    marginBottom: 20,
  },
  navButton: {
    flex: 1,
  },
  completeButton: {
    flex: 2,
    backgroundColor: '#10B981',
  },
  listTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
    marginBottom: 16,
  },
  exerciseList: {
    gap: 12,
  },
  exerciseListItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 12,
    backgroundColor: '#374151',
  },
  exerciseListItemActive: {
    backgroundColor: '#1E3A8A20',
    borderWidth: 1,
    borderColor: '#3B82F6',
  },
  exerciseListItemCompleted: {
    backgroundColor: '#06402420',
    borderWidth: 1,
    borderColor: '#10B981',
  },
  exerciseListNumber: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#1E293B',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  exerciseNumber: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#94A3B8',
  },
  exerciseNumberActive: {
    color: '#3B82F6',
  },
  exerciseListInfo: {
    flex: 1,
  },
  exerciseListName: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#FFFFFF',
    marginBottom: 2,
  },
  exerciseListNameActive: {
    color: '#3B82F6',
  },
  exerciseListNameCompleted: {
    color: '#10B981',
  },
  exerciseListDuration: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#94A3B8',
  },
});