import { ScrollView, View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import SafeAreaWrapper from '@/components/SafeAreaWrapper';
import Card from '@/components/Card';
import Button from '@/components/Button';
import { Heart, Play, Clock, CircleAlert as AlertCircle, CircleCheck as CheckCircle, Thermometer, Zap, Moon, ChevronRight } from 'lucide-react-native';

export default function RecoveryScreen() {
  const activeIssues = [
    {
      id: 1,
      title: 'Left Calf Tightness',
      severity: 'mild',
      duration: '2 days',
      recommendation: 'Gentle stretching and foam rolling',
      status: 'improving',
      icon: AlertCircle,
      color: '#F59E0B',
    },
    {
      id: 2,
      title: 'Lower Back Stiffness',
      severity: 'mild',
      duration: '4 days',
      recommendation: 'Hip flexor stretches and core work',
      status: 'stable',
      icon: AlertCircle,
      color: '#EF4444',
    },
  ];

  const recoveryProtocols = [
    {
      id: 1,
      title: 'Calf Strain Recovery',
      type: 'Active Recovery',
      duration: '15 min',
      phases: ['Gentle stretching', 'Foam rolling', 'Light mobility'],
      image: 'https://images.pexels.com/photos/4056723/pexels-photo-4056723.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      id: 2,
      title: 'Lower Back Relief',
      type: 'Targeted Treatment',
      duration: '20 min',
      phases: ['Heat therapy', 'Gentle stretches', 'Core activation'],
      image: 'https://images.pexels.com/photos/4056532/pexels-photo-4056532.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
  ];

  const recoveryTools = [
    {
      id: 1,
      title: 'Ice Bath Timer',
      description: 'Guided cold therapy session',
      icon: Thermometer,
      color: '#0891B2',
    },
    {
      id: 2,
      title: 'Recovery Meditation',
      description: 'Stress reduction and pain management',
      icon: Moon,
      color: '#6366F1',
    },
    {
      id: 3,
      title: 'Progressive Loading',
      description: 'Gradual return to activity',
      icon: Zap,
      color: '#10B981',
    },
  ];

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'mild':
        return '#F59E0B';
      case 'moderate':
        return '#EF4444';
      case 'severe':
        return '#DC2626';
      default:
        return '#64748B';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'improving':
        return '#10B981';
      case 'stable':
        return '#F59E0B';
      case 'worsening':
        return '#EF4444';
      default:
        return '#64748B';
    }
  };

  return (
    <SafeAreaWrapper>
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Recovery Center</Text>
          <Text style={styles.subtitle}>
            Manage minor injuries and optimize your recovery process
          </Text>
        </View>

        {/* Active Issues */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Active Issues</Text>
          {activeIssues.length > 0 ? (
            activeIssues.map((issue) => {
              const IconComponent = issue.icon;
              return (
                <Card key={issue.id} style={styles.issueCard}>
                  <View style={styles.issueHeader}>
                    <View style={[styles.issueIcon, { backgroundColor: issue.color + '20' }]}>
                      <IconComponent size={20} color={issue.color} />
                    </View>
                    <View style={styles.issueInfo}>
                      <Text style={styles.issueTitle}>{issue.title}</Text>
                      <View style={styles.issueMeta}>
                        <Text style={[styles.severityText, { color: getSeverityColor(issue.severity) }]}>
                          {issue.severity.toUpperCase()}
                        </Text>
                        <Text style={styles.durationText}>• {issue.duration}</Text>
                      </View>
                    </View>
                    <View style={styles.statusContainer}>
                      <View 
                        style={[
                          styles.statusDot, 
                          { backgroundColor: getStatusColor(issue.status) }
                        ]} 
                      />
                      <Text style={[styles.statusText, { color: getStatusColor(issue.status) }]}>
                        {issue.status}
                      </Text>
                    </View>
                  </View>
                  <Text style={styles.recommendationText}>
                    Recommendation: {issue.recommendation}
                  </Text>
                </Card>
              );
            })
          ) : (
            <Card style={styles.noIssuesCard}>
              <CheckCircle size={48} color="#10B981" />
              <Text style={styles.noIssuesTitle}>No Active Issues</Text>
              <Text style={styles.noIssuesSubtitle}>
                Great! You don't have any reported injuries or discomfort.
              </Text>
            </Card>
          )}
        </View>

        {/* Recovery Protocols */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recovery Protocols</Text>
          {recoveryProtocols.map((protocol) => (
            <Card key={protocol.id} style={styles.protocolCard}>
              <View style={styles.protocolContent}>
                <Image source={{ uri: protocol.image }} style={styles.protocolImage} />
                <View style={styles.protocolInfo}>
                  <Text style={styles.protocolTitle}>{protocol.title}</Text>
                  <Text style={styles.protocolType}>{protocol.type}</Text>
                  <View style={styles.protocolMeta}>
                    <Clock size={14} color="#64748B" />
                    <Text style={styles.protocolDuration}>{protocol.duration}</Text>
                  </View>
                  <View style={styles.protocolPhases}>
                    {protocol.phases.map((phase, index) => (
                      <Text key={index} style={styles.phaseText}>
                        • {phase}
                      </Text>
                    ))}
                  </View>
                </View>
              </View>
              <Button
                title="Start Protocol"
                onPress={() => {}}
                style={styles.protocolButton}
              />
            </Card>
          ))}
        </View>

        {/* Recovery Tools */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recovery Tools</Text>
          <View style={styles.toolsGrid}>
            {recoveryTools.map((tool) => {
              const IconComponent = tool.icon;
              return (
                <Card key={tool.id} style={styles.toolCard}>
                  <TouchableOpacity style={styles.toolContent}>
                    <View style={[styles.toolIcon, { backgroundColor: tool.color + '20' }]}>
                      <IconComponent size={24} color={tool.color} />
                    </View>
                    <Text style={styles.toolTitle}>{tool.title}</Text>
                    <Text style={styles.toolDescription}>{tool.description}</Text>
                  </TouchableOpacity>
                </Card>
              );
            })}
          </View>
        </View>

        {/* Quick Actions */}
        <Card style={styles.quickActionsCard}>
          <Text style={styles.quickActionsTitle}>Quick Actions</Text>
          <View style={styles.quickActionsList}>
            <TouchableOpacity style={styles.quickAction}>
              <View style={styles.quickActionIcon}>
                <AlertCircle size={20} color="#EF4444" />
              </View>
              <Text style={styles.quickActionText}>Report New Issue</Text>
              <ChevronRight size={16} color="#64748B" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.quickAction}>
              <View style={styles.quickActionIcon}>
                <Heart size={20} color="#EC4899" />
              </View>
              <Text style={styles.quickActionText}>Pain Assessment</Text>
              <ChevronRight size={16} color="#64748B" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.quickAction}>
              <View style={styles.quickActionIcon}>
                <Play size={20} color="#10B981" />
              </View>
              <Text style={styles.quickActionText}>Return to Play Test</Text>
              <ChevronRight size={16} color="#64748B" />
            </TouchableOpacity>
          </View>
        </Card>
      </ScrollView>
    </SafeAreaWrapper>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#0F172A',
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginTop: 8,
    lineHeight: 22,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginBottom: 16,
    paddingHorizontal: 20,
  },
  issueCard: {
    marginHorizontal: 20,
    marginBottom: 12,
    borderLeftWidth: 4,
    borderLeftColor: '#F59E0B',
  },
  issueHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  issueIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  issueInfo: {
    flex: 1,
  },
  issueTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginBottom: 4,
  },
  issueMeta: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  severityText: {
    fontSize: 12,
    fontFamily: 'Inter-Bold',
  },
  durationText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginLeft: 8,
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 4,
  },
  statusText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    textTransform: 'capitalize',
  },
  recommendationText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    lineHeight: 20,
  },
  noIssuesCard: {
    marginHorizontal: 20,
    alignItems: 'center',
    padding: 32,
    backgroundColor: '#F0FDF4',
    borderWidth: 1,
    borderColor: '#BBF7D0',
  },
  noIssuesTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginTop: 16,
    marginBottom: 8,
  },
  noIssuesSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    textAlign: 'center',
    lineHeight: 20,
  },
  protocolCard: {
    marginHorizontal: 20,
    marginBottom: 16,
  },
  protocolContent: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  protocolImage: {
    width: 80,
    height: 80,
    borderRadius: 8,
    marginRight: 16,
  },
  protocolInfo: {
    flex: 1,
  },
  protocolTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginBottom: 4,
  },
  protocolType: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#2563EB',
    marginBottom: 8,
  },
  protocolMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  protocolDuration: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginLeft: 4,
  },
  protocolPhases: {
    gap: 2,
  },
  phaseText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
  protocolButton: {
    alignSelf: 'flex-start',
  },
  toolsGrid: {
    paddingHorizontal: 20,
    gap: 12,
  },
  toolCard: {
    padding: 16,
  },
  toolContent: {
    alignItems: 'center',
  },
  toolIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  toolTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginBottom: 4,
    textAlign: 'center',
  },
  toolDescription: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    textAlign: 'center',
    lineHeight: 18,
  },
  quickActionsCard: {
    marginHorizontal: 20,
    marginBottom: 32,
  },
  quickActionsTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginBottom: 16,
  },
  quickActionsList: {
    gap: 12,
  },
  quickAction: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
  },
  quickActionIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#F1F5F9',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  quickActionText: {
    flex: 1,
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#0F172A',
  },
});