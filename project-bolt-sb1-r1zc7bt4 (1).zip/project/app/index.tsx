import { useEffect } from 'react';
import { router } from 'expo-router';

export default function IndexScreen() {
  useEffect(() => {
    // In a real app, you would check authentication status here
    // For now, we'll always redirect to welcome
    router.replace('/auth/welcome');
  }, []);

  return null;
}