import { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { router } from 'expo-router';
import SafeAreaWrapper from '@/components/SafeAreaWrapper';
import Button from '@/components/Button';
import { ArrowLeft, Target, Shield, TrendingUp, Heart, Users, Trophy } from 'lucide-react-native';

export default function GoalsScreen() {
  const [selectedGoals, setSelectedGoals] = useState<string[]>([]);
  const [primaryReason, setPrimaryReason] = useState('');

  const goals = [
    {
      id: 'prevent-injuries',
      title: 'Prevent Injuries',
      description: 'Stay healthy and avoid time off from sports',
      icon: Shield,
      color: '#2563EB',
    },
    {
      id: 'improve-performance',
      title: 'Improve Performance',
      description: 'Enhance athletic ability and competitive edge',
      icon: TrendingUp,
      color: '#10B981',
    },
    {
      id: 'recover-faster',
      title: 'Recover Faster',
      description: 'Bounce back quicker from training and games',
      icon: Heart,
      color: '#EC4899',
    },
    {
      id: 'return-from-injury',
      title: 'Return from Injury',
      description: 'Safely get back to playing after an injury',
      icon: Target,
      color: '#F59E0B',
    },
    {
      id: 'team-guidance',
      title: 'Team/Coach Guidance',
      description: 'Get recommendations for my team or athletes',
      icon: Users,
      color: '#0891B2',
    },
    {
      id: 'long-term-health',
      title: 'Long-term Health',
      description: 'Maintain athletic ability as I age',
      icon: Trophy,
      color: '#EA580C',
    },
  ];

  const reasons = [
    'I want to prevent injuries before they happen',
    'I\'m currently dealing with an injury',
    'I\'ve had injuries in the past and want to avoid them',
    'My coach/trainer recommended injury prevention',
    'I want to improve my overall athletic performance',
    'I\'m getting older and want to stay healthy',
  ];

  const toggleGoal = (goalId: string) => {
    setSelectedGoals(prev => 
      prev.includes(goalId)
        ? prev.filter(id => id !== goalId)
        : [...prev, goalId]
    );
  };

  const isFormValid = selectedGoals.length > 0 && primaryReason;

  const handleContinue = () => {
    if (isFormValid) {
      router.push('/onboarding/complete');
    }
  };

  return (
    <SafeAreaWrapper style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <ArrowLeft size={24} color="#64748B" />
        </TouchableOpacity>
        <View style={styles.progressContainer}>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { width: '100%' }]} />
          </View>
          <Text style={styles.progressText}>4 of 4</Text>
        </View>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.titleSection}>
          <Text style={styles.title}>What are your goals?</Text>
          <Text style={styles.subtitle}>
            Help us understand what you want to achieve so we can personalize your experience
          </Text>
        </View>

        {/* Goals Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Select all that apply to you:</Text>
          <View style={styles.goalsGrid}>
            {goals.map((goal) => {
              const IconComponent = goal.icon;
              const isSelected = selectedGoals.includes(goal.id);
              
              return (
                <TouchableOpacity
                  key={goal.id}
                  style={[
                    styles.goalCard,
                    isSelected && styles.goalCardSelected
                  ]}
                  onPress={() => toggleGoal(goal.id)}
                >
                  <View style={[
                    styles.goalIcon,
                    { backgroundColor: goal.color + '20' },
                    isSelected && { backgroundColor: goal.color + '30' }
                  ]}>
                    <IconComponent 
                      size={24} 
                      color={isSelected ? goal.color : '#64748B'} 
                    />
                  </View>
                  <Text style={[
                    styles.goalTitle,
                    isSelected && styles.goalTitleSelected
                  ]}>
                    {goal.title}
                  </Text>
                  <Text style={[
                    styles.goalDescription,
                    isSelected && styles.goalDescriptionSelected
                  ]}>
                    {goal.description}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        {/* Primary Reason */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>What brought you to PreventIQ?</Text>
          <Text style={styles.sectionSubtitle}>Choose your primary reason</Text>
          <View style={styles.reasonsList}>
            {reasons.map((reason) => (
              <TouchableOpacity
                key={reason}
                style={[
                  styles.reasonCard,
                  primaryReason === reason && styles.reasonCardSelected
                ]}
                onPress={() => setPrimaryReason(reason)}
              >
                <View style={[
                  styles.radioButton,
                  primaryReason === reason && styles.radioButtonSelected
                ]}>
                  {primaryReason === reason && <View style={styles.radioButtonInner} />}
                </View>
                <Text style={[
                  styles.reasonText,
                  primaryReason === reason && styles.reasonTextSelected
                ]}>
                  {reason}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </ScrollView>

      <View style={styles.footer}>
        <Button
          title="Complete Setup"
          onPress={handleContinue}
          disabled={!isFormValid}
          style={styles.continueButton}
        />
      </View>
    </SafeAreaWrapper>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 16,
    gap: 16,
  },
  backButton: {
    padding: 8,
  },
  progressContainer: {
    flex: 1,
    alignItems: 'center',
  },
  progressBar: {
    width: '100%',
    height: 4,
    backgroundColor: '#E2E8F0',
    borderRadius: 2,
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#2563EB',
    borderRadius: 2,
  },
  progressText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#64748B',
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
  },
  titleSection: {
    marginBottom: 32,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#0F172A',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    lineHeight: 24,
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginBottom: 8,
  },
  sectionSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    marginBottom: 16,
  },
  goalsGrid: {
    gap: 16,
  },
  goalCard: {
    padding: 20,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    backgroundColor: '#FFFFFF',
    flexDirection: 'row',
    alignItems: 'center',
  },
  goalCardSelected: {
    borderColor: '#2563EB',
    backgroundColor: '#EFF6FF',
  },
  goalIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  goalTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginBottom: 4,
    flex: 1,
  },
  goalTitleSelected: {
    color: '#2563EB',
  },
  goalDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    flex: 1,
    lineHeight: 20,
  },
  goalDescriptionSelected: {
    color: '#1E40AF',
  },
  reasonsList: {
    gap: 12,
  },
  reasonCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    backgroundColor: '#FFFFFF',
  },
  reasonCardSelected: {
    borderColor: '#2563EB',
    backgroundColor: '#EFF6FF',
  },
  radioButton: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#E2E8F0',
    marginRight: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioButtonSelected: {
    borderColor: '#2563EB',
  },
  radioButtonInner: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#2563EB',
  },
  reasonText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    flex: 1,
    lineHeight: 22,
  },
  reasonTextSelected: {
    color: '#2563EB',
    fontFamily: 'Inter-Medium',
  },
  footer: {
    paddingHorizontal: 24,
    paddingBottom: 32,
    paddingTop: 16,
  },
  continueButton: {
    width: '100%',
  },
});