import { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { router } from 'expo-router';
import SafeAreaWrapper from '@/components/SafeAreaWrapper';
import Button from '@/components/Button';
import { ArrowLeft, Calendar } from 'lucide-react-native';

export default function BasicsScreen() {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState({
    age: '',
    height: '',
    gender: '',
  });

  const steps = [
    {
      id: 'age',
      title: 'What\'s your age range?',
      subtitle: 'This helps us create age-appropriate recommendations',
      icon: Calendar,
      options: ['13-15', '16-18', '19-22', '23-25', '26-30', '31-35', '36-40', '40+'],
      field: 'age'
    },
    {
      id: 'height',
      title: 'What\'s your height range?',
      subtitle: 'Height affects biomechanics and injury risk patterns',
      icon: Calendar,
      options: ["Under 5'0\"", "5'0\" - 5'3\"", "5'4\" - 5'7\"", "5'8\" - 5'11\"", "6'0\" - 6'3\"", "6'4\" - 6'7\"", "Over 6'7\""],
      field: 'height'
    },
    {
      id: 'gender',
      title: 'What\'s your gender?',
      subtitle: 'Gender affects injury patterns and prevention strategies',
      icon: Calendar,
      options: ['Male', 'Female', 'Non-binary', 'Prefer not to say'],
      field: 'gender'
    }
  ];

  const currentStepData = steps[currentStep];
  const isLastStep = currentStep === steps.length - 1;
  const canContinue = formData[currentStepData.field as keyof typeof formData];

  const handleOptionSelect = (option: string) => {
    setFormData(prev => ({ ...prev, [currentStepData.field]: option }));
  };

  const handleNext = () => {
    if (isLastStep) {
      router.push('/onboarding/athletic-background');
    } else {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handleBack = () => {
    if (currentStep === 0) {
      router.back();
    } else {
      setCurrentStep(prev => prev - 1);
    }
  };

  return (
    <SafeAreaWrapper style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={handleBack}
        >
          <ArrowLeft size={24} color="#94A3B8" />
        </TouchableOpacity>
        <View style={styles.progressContainer}>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { width: `${((currentStep + 1) / steps.length) * 100}%` }]} />
          </View>
          <Text style={styles.progressText}>{currentStep + 1} of {steps.length}</Text>
        </View>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.questionContainer}>
          <View style={styles.iconContainer}>
            <currentStepData.icon size={32} color="#3B82F6" />
          </View>
          
          <Text style={styles.title}>{currentStepData.title}</Text>
          <Text style={styles.subtitle}>{currentStepData.subtitle}</Text>

          <View style={styles.optionsContainer}>
            {currentStepData.options.map((option) => (
              <TouchableOpacity
                key={option}
                style={[
                  styles.optionCard,
                  formData[currentStepData.field as keyof typeof formData] === option && styles.optionCardSelected
                ]}
                onPress={() => handleOptionSelect(option)}
              >
                <View style={[
                  styles.radioButton,
                  formData[currentStepData.field as keyof typeof formData] === option && styles.radioButtonSelected
                ]}>
                  {formData[currentStepData.field as keyof typeof formData] === option && (
                    <View style={styles.radioButtonInner} />
                  )}
                </View>
                <Text style={[
                  styles.optionText,
                  formData[currentStepData.field as keyof typeof formData] === option && styles.optionTextSelected
                ]}>
                  {option}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </ScrollView>

      <View style={styles.footer}>
        <Button
          title={isLastStep ? "Continue" : "Next"}
          onPress={handleNext}
          disabled={!canContinue}
          style={styles.continueButton}
        />
      </View>
    </SafeAreaWrapper>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 16,
    gap: 16,
  },
  backButton: {
    padding: 8,
  },
  progressContainer: {
    flex: 1,
    alignItems: 'center',
  },
  progressBar: {
    width: '100%',
    height: 4,
    backgroundColor: '#374151',
    borderRadius: 2,
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#3B82F6',
    borderRadius: 2,
  },
  progressText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#94A3B8',
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
  },
  questionContainer: {
    alignItems: 'center',
    paddingTop: 40,
  },
  iconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#1E3A8A20',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 32,
    borderWidth: 2,
    borderColor: '#3B82F6',
  },
  title: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: 12,
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#94A3B8',
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 40,
    paddingHorizontal: 20,
  },
  optionsContainer: {
    width: '100%',
    gap: 16,
  },
  optionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 20,
    paddingHorizontal: 24,
    borderRadius: 16,
    borderWidth: 2,
    borderColor: '#374151',
    backgroundColor: '#1E293B',
  },
  optionCardSelected: {
    borderColor: '#3B82F6',
    backgroundColor: '#1E3A8A20',
  },
  radioButton: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#374151',
    marginRight: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioButtonSelected: {
    borderColor: '#3B82F6',
  },
  radioButtonInner: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#3B82F6',
  },
  optionText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#94A3B8',
    flex: 1,
  },
  optionTextSelected: {
    color: '#FFFFFF',
    fontFamily: 'Inter-SemiBold',
  },
  footer: {
    paddingHorizontal: 24,
    paddingBottom: 32,
    paddingTop: 16,
  },
  continueButton: {
    width: '100%',
  },
});