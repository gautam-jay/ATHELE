import { View, Text, StyleSheet, Image } from 'react-native';
import { router } from 'expo-router';
import SafeAreaWrapper from '@/components/SafeAreaWrapper';
import Button from '@/components/Button';
import { CircleCheck as CheckCircle, Target, Shield, TrendingUp } from 'lucide-react-native';

export default function CompleteScreen() {
  const handleGetStarted = () => {
    router.replace('/(tabs)');
  };

  return (
    <SafeAreaWrapper style={styles.container}>
      <View style={styles.content}>
        {/* Success Icon */}
        <View style={styles.successSection}>
          <View style={styles.successIcon}>
            <CheckCircle size={64} color="#10B981" />
          </View>
          <Text style={styles.successTitle}>Setup Complete!</Text>
          <Text style={styles.successSubtitle}>
            Your personalized injury prevention program is ready
          </Text>
        </View>

        {/* What's Next */}
        <View style={styles.nextStepsSection}>
          <Text style={styles.nextStepsTitle}>What's next?</Text>
          
          <View style={styles.stepsList}>
            <View style={styles.step}>
              <View style={styles.stepIcon}>
                <Target size={24} color="#2563EB" />
              </View>
              <View style={styles.stepContent}>
                <Text style={styles.stepTitle}>Personalized Assessment</Text>
                <Text style={styles.stepDescription}>
                  Complete movement screens tailored to your sport
                </Text>
              </View>
            </View>

            <View style={styles.step}>
              <View style={styles.stepIcon}>
                <Shield size={24} color="#10B981" />
              </View>
              <View style={styles.stepContent}>
                <Text style={styles.stepTitle}>Custom Prevention Program</Text>
                <Text style={styles.stepDescription}>
                  Get daily routines designed for your risk factors
                </Text>
              </View>
            </View>

            <View style={styles.step}>
              <View style={styles.stepIcon}>
                <TrendingUp size={24} color="#0891B2" />
              </View>
              <View style={styles.stepContent}>
                <Text style={styles.stepTitle}>Track Your Progress</Text>
                <Text style={styles.stepDescription}>
                  Monitor your health metrics and injury risk daily
                </Text>
              </View>
            </View>
          </View>
        </View>

        {/* Motivational Image */}
        <View style={styles.imageSection}>
          <Image 
            source={{ uri: 'https://images.pexels.com/photos/3823488/pexels-photo-3823488.jpeg?auto=compress&cs=tinysrgb&w=400' }}
            style={styles.motivationalImage}
          />
        </View>
      </View>

      <View style={styles.footer}>
        <Button
          title="Get Started"
          onPress={handleGetStarted}
          style={styles.getStartedButton}
        />
        <Text style={styles.footerText}>
          Ready to prevent injuries and optimize your performance!
        </Text>
      </View>
    </SafeAreaWrapper>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 40,
  },
  successSection: {
    alignItems: 'center',
    marginBottom: 48,
  },
  successIcon: {
    marginBottom: 24,
  },
  successTitle: {
    fontSize: 32,
    fontFamily: 'Inter-Bold',
    color: '#0F172A',
    marginBottom: 12,
    textAlign: 'center',
  },
  successSubtitle: {
    fontSize: 18,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    textAlign: 'center',
    lineHeight: 26,
  },
  nextStepsSection: {
    marginBottom: 32,
  },
  nextStepsTitle: {
    fontSize: 20,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginBottom: 24,
    textAlign: 'center',
  },
  stepsList: {
    gap: 20,
  },
  step: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  stepIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#F8FAFC',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  stepContent: {
    flex: 1,
    paddingTop: 4,
  },
  stepTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginBottom: 4,
  },
  stepDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    lineHeight: 20,
  },
  imageSection: {
    alignItems: 'center',
    marginBottom: 32,
  },
  motivationalImage: {
    width: 200,
    height: 150,
    borderRadius: 16,
  },
  footer: {
    paddingHorizontal: 24,
    paddingBottom: 32,
    alignItems: 'center',
  },
  getStartedButton: {
    width: '100%',
    marginBottom: 16,
  },
  footerText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    textAlign: 'center',
  },
});