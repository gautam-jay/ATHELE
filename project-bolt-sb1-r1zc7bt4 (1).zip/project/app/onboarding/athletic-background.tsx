import { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { router } from 'expo-router';
import SafeAreaWrapper from '@/components/SafeAreaWrapper';
import Button from '@/components/Button';
import { ArrowLeft, Trophy, Target, Users } from 'lucide-react-native';

export default function AthleticBackgroundScreen() {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState({
    sports: [] as string[],
    primarySport: '',
    competitionLevel: '',
    position: '',
  });

  const sports = [
    'Soccer', 'Basketball', 'Football', 'Baseball', 'Tennis', 'Track & Field',
    'Swimming', 'Volleyball', 'Wrestling', 'Cross Country', 'Golf', 'Softball',
    'Lacrosse', 'Hockey', 'Gymnastics', 'Other'
  ];

  const competitionLevels = [
    'Recreational/Casual',
    'High School JV',
    'High School Varsity',
    'Club/Travel Team',
    'College Division III',
    'College Division II',
    'College Division I',
    'Semi-Professional',
    'Professional'
  ];

  const getPositionsForSport = (sport: string) => {
    const positions: Record<string, string[]> = {
      'Soccer': ['Goalkeeper', 'Defender', 'Midfielder', 'Forward'],
      'Basketball': ['Point Guard', 'Shooting Guard', 'Small Forward', 'Power Forward', 'Center'],
      'Football': ['Quarterback', 'Running Back', 'Wide Receiver', 'Tight End', 'Offensive Line', 'Defensive Line', 'Linebacker', 'Defensive Back', 'Kicker/Punter'],
      'Baseball': ['Pitcher', 'Catcher', 'First Base', 'Second Base', 'Third Base', 'Shortstop', 'Outfield'],
      'Volleyball': ['Setter', 'Outside Hitter', 'Middle Blocker', 'Opposite Hitter', 'Libero'],
      'Hockey': ['Goalie', 'Defenseman', 'Left Wing', 'Right Wing', 'Center'],
    };
    return positions[sport] || ['Not Applicable'];
  };

  const steps = [
    {
      id: 'sports',
      title: 'What sports do you play?',
      subtitle: 'Select all sports you participate in regularly',
      icon: Trophy,
      type: 'multi-select' as const,
      options: sports,
      field: 'sports'
    },
    {
      id: 'primarySport',
      title: 'What\'s your primary sport?',
      subtitle: 'Which sport do you focus on most?',
      icon: Target,
      type: 'single-select' as const,
      options: formData.sports,
      field: 'primarySport'
    },
    {
      id: 'competitionLevel',
      title: 'What\'s your competition level?',
      subtitle: 'This helps us tailor the intensity of recommendations',
      icon: Trophy,
      type: 'single-select' as const,
      options: competitionLevels,
      field: 'competitionLevel'
    },
    {
      id: 'position',
      title: 'What position do you play?',
      subtitle: 'Position-specific training reduces injury risk',
      icon: Users,
      type: 'single-select' as const,
      options: getPositionsForSport(formData.primarySport),
      field: 'position'
    }
  ];

  // Filter steps based on current data
  const getAvailableSteps = () => {
    let availableSteps = [steps[0]]; // Always show sports selection
    
    if (formData.sports.length > 1) {
      availableSteps.push(steps[1]); // Primary sport selection
    } else if (formData.sports.length === 1) {
      // Auto-select primary sport if only one sport selected
      if (formData.primarySport !== formData.sports[0]) {
        setFormData(prev => ({ ...prev, primarySport: formData.sports[0] }));
      }
    }
    
    if (formData.primarySport || formData.sports.length === 1) {
      availableSteps.push(steps[2]); // Competition level
    }
    
    if (formData.primarySport && getPositionsForSport(formData.primarySport)[0] !== 'Not Applicable') {
      availableSteps.push(steps[3]); // Position
    }
    
    return availableSteps;
  };

  const availableSteps = getAvailableSteps();
  const currentStepData = availableSteps[currentStep];
  const isLastStep = currentStep === availableSteps.length - 1;

  const canContinue = () => {
    if (!currentStepData) return false;
    
    if (currentStepData.type === 'multi-select') {
      return formData.sports.length > 0;
    } else {
      return formData[currentStepData.field as keyof typeof formData];
    }
  };

  const handleOptionSelect = (option: string) => {
    if (currentStepData.type === 'multi-select') {
      setFormData(prev => {
        const newSports = prev.sports.includes(option)
          ? prev.sports.filter(s => s !== option)
          : [...prev.sports, option];
        
        // Reset dependent fields when sports change
        return {
          ...prev,
          sports: newSports,
          primarySport: newSports.length === 1 ? newSports[0] : (newSports.includes(prev.primarySport) ? prev.primarySport : ''),
          position: '',
        };
      });
    } else {
      setFormData(prev => ({ ...prev, [currentStepData.field]: option }));
    }
  };

  const handleNext = () => {
    if (isLastStep) {
      router.push('/onboarding/injury-history');
    } else {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handleBack = () => {
    if (currentStep === 0) {
      router.back();
    } else {
      setCurrentStep(prev => prev - 1);
    }
  };

  if (!currentStepData) return null;

  return (
    <SafeAreaWrapper style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={handleBack}
        >
          <ArrowLeft size={24} color="#94A3B8" />
        </TouchableOpacity>
        <View style={styles.progressContainer}>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { width: `${((currentStep + 1) / availableSteps.length) * 100}%` }]} />
          </View>
          <Text style={styles.progressText}>{currentStep + 1} of {availableSteps.length}</Text>
        </View>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.questionContainer}>
          <View style={styles.iconContainer}>
            <currentStepData.icon size={32} color="#3B82F6" />
          </View>
          
          <Text style={styles.title}>{currentStepData.title}</Text>
          <Text style={styles.subtitle}>{currentStepData.subtitle}</Text>

          <View style={styles.optionsContainer}>
            {currentStepData.type === 'multi-select' ? (
              <View style={styles.multiSelectGrid}>
                {currentStepData.options.map((option) => (
                  <TouchableOpacity
                    key={option}
                    style={[
                      styles.multiSelectCard,
                      formData.sports.includes(option) && styles.multiSelectCardSelected
                    ]}
                    onPress={() => handleOptionSelect(option)}
                  >
                    <Text style={[
                      styles.multiSelectText,
                      formData.sports.includes(option) && styles.multiSelectTextSelected
                    ]}>
                      {option}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            ) : (
              currentStepData.options.map((option) => (
                <TouchableOpacity
                  key={option}
                  style={[
                    styles.optionCard,
                    formData[currentStepData.field as keyof typeof formData] === option && styles.optionCardSelected
                  ]}
                  onPress={() => handleOptionSelect(option)}
                >
                  <View style={[
                    styles.radioButton,
                    formData[currentStepData.field as keyof typeof formData] === option && styles.radioButtonSelected
                  ]}>
                    {formData[currentStepData.field as keyof typeof formData] === option && (
                      <View style={styles.radioButtonInner} />
                    )}
                  </View>
                  <Text style={[
                    styles.optionText,
                    formData[currentStepData.field as keyof typeof formData] === option && styles.optionTextSelected
                  ]}>
                    {option}
                  </Text>
                </TouchableOpacity>
              ))
            )}
          </View>
        </View>
      </ScrollView>

      <View style={styles.footer}>
        <Button
          title={isLastStep ? "Continue" : "Next"}
          onPress={handleNext}
          disabled={!canContinue()}
          style={styles.continueButton}
        />
      </View>
    </SafeAreaWrapper>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 16,
    gap: 16,
  },
  backButton: {
    padding: 8,
  },
  progressContainer: {
    flex: 1,
    alignItems: 'center',
  },
  progressBar: {
    width: '100%',
    height: 4,
    backgroundColor: '#374151',
    borderRadius: 2,
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#3B82F6',
    borderRadius: 2,
  },
  progressText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#94A3B8',
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
  },
  questionContainer: {
    alignItems: 'center',
    paddingTop: 40,
  },
  iconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#1E3A8A20',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 32,
    borderWidth: 2,
    borderColor: '#3B82F6',
  },
  title: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: 12,
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#94A3B8',
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 40,
    paddingHorizontal: 20,
  },
  optionsContainer: {
    width: '100%',
  },
  multiSelectGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    justifyContent: 'center',
  },
  multiSelectCard: {
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#374151',
    backgroundColor: '#1E293B',
  },
  multiSelectCardSelected: {
    borderColor: '#3B82F6',
    backgroundColor: '#1E3A8A20',
  },
  multiSelectText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#94A3B8',
    textAlign: 'center',
  },
  multiSelectTextSelected: {
    color: '#FFFFFF',
    fontFamily: 'Inter-SemiBold',
  },
  optionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 20,
    paddingHorizontal: 24,
    borderRadius: 16,
    borderWidth: 2,
    borderColor: '#374151',
    backgroundColor: '#1E293B',
    marginBottom: 16,
  },
  optionCardSelected: {
    borderColor: '#3B82F6',
    backgroundColor: '#1E3A8A20',
  },
  radioButton: {
    width: 24,
    height: 24,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#374151',
    marginRight: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioButtonSelected: {
    borderColor: '#3B82F6',
  },
  radioButtonInner: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#3B82F6',
  },
  optionText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#94A3B8',
    flex: 1,
  },
  optionTextSelected: {
    color: '#FFFFFF',
    fontFamily: 'Inter-SemiBold',
  },
  footer: {
    paddingHorizontal: 24,
    paddingBottom: 32,
    paddingTop: 16,
  },
  continueButton: {
    width: '100%',
  },
});