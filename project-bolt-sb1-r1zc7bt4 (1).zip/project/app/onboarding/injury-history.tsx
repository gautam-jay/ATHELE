import { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, TextInput } from 'react-native';
import { router } from 'expo-router';
import SafeAreaWrapper from '@/components/SafeAreaWrapper';
import Button from '@/components/Button';
import { ArrowLeft, TriangleAlert as AlertTriangle, Plus, X } from 'lucide-react-native';

interface Injury {
  id: string;
  bodyPart: string;
  type: string;
  timeframe: string;
}

export default function InjuryHistoryScreen() {
  const [hasInjuries, setHasInjuries] = useState<boolean | null>(null);
  const [currentInjury, setCurrentInjury] = useState<boolean | null>(null);
  const [injuries, setInjuries] = useState<Injury[]>([]);
  const [showAddInjury, setShowAddInjury] = useState(false);
  const [newInjury, setNewInjury] = useState({
    bodyPart: '',
    type: '',
    timeframe: '',
  });

  const bodyParts = [
    'Ankle', 'Knee', 'Hip', 'Lower Back', 'Upper Back', 'Shoulder', 
    'Elbow', 'Wrist', 'Neck', 'Hamstring', 'Quadriceps', 'Calf', 'Other'
  ];

  const injuryTypes = [
    'Sprain', 'Strain', 'Fracture', 'Dislocation', 'Concussion', 
    'Tendinitis', 'Ligament Tear', 'Muscle Pull', 'Other'
  ];

  const timeframes = [
    'Currently injured', 'Within last month', '1-3 months ago', 
    '3-6 months ago', '6-12 months ago', 'Over a year ago'
  ];

  const addInjury = () => {
    if (newInjury.bodyPart && newInjury.type && newInjury.timeframe) {
      const injury: Injury = {
        id: Date.now().toString(),
        ...newInjury,
      };
      setInjuries(prev => [...prev, injury]);
      setNewInjury({ bodyPart: '', type: '', timeframe: '' });
      setShowAddInjury(false);
    }
  };

  const removeInjury = (id: string) => {
    setInjuries(prev => prev.filter(injury => injury.id !== id));
  };

  const isFormValid = hasInjuries !== null && currentInjury !== null;

  const handleContinue = () => {
    if (isFormValid) {
      router.push('/onboarding/goals');
    }
  };

  return (
    <SafeAreaWrapper style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity 
          style={styles.backButton}
          onPress={() => router.back()}
        >
          <ArrowLeft size={24} color="#64748B" />
        </TouchableOpacity>
        <View style={styles.progressContainer}>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { width: '75%' }]} />
          </View>
          <Text style={styles.progressText}>3 of 4</Text>
        </View>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.titleSection}>
          <Text style={styles.title}>Injury History</Text>
          <Text style={styles.subtitle}>
            Understanding your injury history helps us create better prevention strategies
          </Text>
        </View>

        {/* Previous Injuries */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <AlertTriangle size={20} color="#2563EB" />
            <Text style={styles.sectionTitle}>Have you had any previous injuries?</Text>
          </View>
          <View style={styles.optionsRow}>
            <TouchableOpacity
              style={[
                styles.yesNoButton,
                hasInjuries === true && styles.yesNoButtonSelected
              ]}
              onPress={() => setHasInjuries(true)}
            >
              <Text style={[
                styles.yesNoText,
                hasInjuries === true && styles.yesNoTextSelected
              ]}>
                Yes
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.yesNoButton,
                hasInjuries === false && styles.yesNoButtonSelected
              ]}
              onPress={() => setHasInjuries(false)}
            >
              <Text style={[
                styles.yesNoText,
                hasInjuries === false && styles.yesNoTextSelected
              ]}>
                No
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Current Injury */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <AlertTriangle size={20} color="#2563EB" />
            <Text style={styles.sectionTitle}>Are you currently injured or dealing with pain?</Text>
          </View>
          <View style={styles.optionsRow}>
            <TouchableOpacity
              style={[
                styles.yesNoButton,
                currentInjury === true && styles.yesNoButtonSelected
              ]}
              onPress={() => setCurrentInjury(true)}
            >
              <Text style={[
                styles.yesNoText,
                currentInjury === true && styles.yesNoTextSelected
              ]}>
                Yes
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.yesNoButton,
                currentInjury === false && styles.yesNoButtonSelected
              ]}
              onPress={() => setCurrentInjury(false)}
            >
              <Text style={[
                styles.yesNoText,
                currentInjury === false && styles.yesNoTextSelected
              ]}>
                No
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Injury Details */}
        {(hasInjuries === true || currentInjury === true) && (
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Injury Details</Text>
              <TouchableOpacity
                style={styles.addButton}
                onPress={() => setShowAddInjury(true)}
              >
                <Plus size={20} color="#2563EB" />
                <Text style={styles.addButtonText}>Add Injury</Text>
              </TouchableOpacity>
            </View>

            {injuries.map((injury) => (
              <View key={injury.id} style={styles.injuryCard}>
                <View style={styles.injuryInfo}>
                  <Text style={styles.injuryTitle}>
                    {injury.bodyPart} - {injury.type}
                  </Text>
                  <Text style={styles.injuryTimeframe}>{injury.timeframe}</Text>
                </View>
                <TouchableOpacity
                  style={styles.removeButton}
                  onPress={() => removeInjury(injury.id)}
                >
                  <X size={16} color="#64748B" />
                </TouchableOpacity>
              </View>
            ))}

            {showAddInjury && (
              <View style={styles.addInjuryForm}>
                <Text style={styles.formTitle}>Add Injury</Text>
                
                <View style={styles.formField}>
                  <Text style={styles.fieldLabel}>Body Part</Text>
                  <View style={styles.optionsGrid}>
                    {bodyParts.map((part) => (
                      <TouchableOpacity
                        key={part}
                        style={[
                          styles.optionChip,
                          newInjury.bodyPart === part && styles.optionChipSelected
                        ]}
                        onPress={() => setNewInjury(prev => ({ ...prev, bodyPart: part }))}
                      >
                        <Text style={[
                          styles.optionChipText,
                          newInjury.bodyPart === part && styles.optionChipTextSelected
                        ]}>
                          {part}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>

                <View style={styles.formField}>
                  <Text style={styles.fieldLabel}>Injury Type</Text>
                  <View style={styles.optionsGrid}>
                    {injuryTypes.map((type) => (
                      <TouchableOpacity
                        key={type}
                        style={[
                          styles.optionChip,
                          newInjury.type === type && styles.optionChipSelected
                        ]}
                        onPress={() => setNewInjury(prev => ({ ...prev, type }))}
                      >
                        <Text style={[
                          styles.optionChipText,
                          newInjury.type === type && styles.optionChipTextSelected
                        ]}>
                          {type}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>

                <View style={styles.formField}>
                  <Text style={styles.fieldLabel}>When did this occur?</Text>
                  <View style={styles.optionsColumn}>
                    {timeframes.map((timeframe) => (
                      <TouchableOpacity
                        key={timeframe}
                        style={[
                          styles.optionRow,
                          newInjury.timeframe === timeframe && styles.optionRowSelected
                        ]}
                        onPress={() => setNewInjury(prev => ({ ...prev, timeframe }))}
                      >
                        <View style={[
                          styles.radioButton,
                          newInjury.timeframe === timeframe && styles.radioButtonSelected
                        ]}>
                          {newInjury.timeframe === timeframe && <View style={styles.radioButtonInner} />}
                        </View>
                        <Text style={[
                          styles.optionRowText,
                          newInjury.timeframe === timeframe && styles.optionRowTextSelected
                        ]}>
                          {timeframe}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>

                <View style={styles.formActions}>
                  <Button
                    title="Cancel"
                    onPress={() => {
                      setShowAddInjury(false);
                      setNewInjury({ bodyPart: '', type: '', timeframe: '' });
                    }}
                    variant="outline"
                    style={styles.cancelButton}
                  />
                  <Button
                    title="Add"
                    onPress={addInjury}
                    disabled={!newInjury.bodyPart || !newInjury.type || !newInjury.timeframe}
                    style={styles.addInjuryButton}
                  />
                </View>
              </View>
            )}
          </View>
        )}
      </ScrollView>

      <View style={styles.footer}>
        <Button
          title="Continue"
          onPress={handleContinue}
          disabled={!isFormValid}
          style={styles.continueButton}
        />
      </View>
    </SafeAreaWrapper>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 16,
    gap: 16,
  },
  backButton: {
    padding: 8,
  },
  progressContainer: {
    flex: 1,
    alignItems: 'center',
  },
  progressBar: {
    width: '100%',
    height: 4,
    backgroundColor: '#E2E8F0',
    borderRadius: 2,
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#2563EB',
    borderRadius: 2,
  },
  progressText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#64748B',
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
  },
  titleSection: {
    marginBottom: 32,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#0F172A',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
    lineHeight: 24,
  },
  section: {
    marginBottom: 32,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
    gap: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    flex: 1,
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  addButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#2563EB',
  },
  optionsRow: {
    flexDirection: 'row',
    gap: 12,
  },
  yesNoButton: {
    flex: 1,
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
  },
  yesNoButtonSelected: {
    borderColor: '#2563EB',
    backgroundColor: '#EFF6FF',
  },
  yesNoText: {
    fontSize: 16,
    fontFamily: 'Inter-Medium',
    color: '#64748B',
  },
  yesNoTextSelected: {
    color: '#2563EB',
  },
  injuryCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    borderRadius: 12,
    backgroundColor: '#F8FAFC',
    borderWidth: 1,
    borderColor: '#E2E8F0',
    marginBottom: 12,
  },
  injuryInfo: {
    flex: 1,
  },
  injuryTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginBottom: 4,
  },
  injuryTimeframe: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
  removeButton: {
    padding: 8,
  },
  addInjuryForm: {
    padding: 20,
    borderRadius: 12,
    backgroundColor: '#F8FAFC',
    borderWidth: 1,
    borderColor: '#E2E8F0',
    marginTop: 16,
  },
  formTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#0F172A',
    marginBottom: 20,
  },
  formField: {
    marginBottom: 20,
  },
  fieldLabel: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#374151',
    marginBottom: 12,
  },
  optionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  optionChip: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    backgroundColor: '#FFFFFF',
  },
  optionChipSelected: {
    borderColor: '#2563EB',
    backgroundColor: '#EFF6FF',
  },
  optionChipText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#64748B',
  },
  optionChipTextSelected: {
    color: '#2563EB',
  },
  optionsColumn: {
    gap: 8,
  },
  optionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    backgroundColor: '#FFFFFF',
  },
  optionRowSelected: {
    borderColor: '#2563EB',
    backgroundColor: '#EFF6FF',
  },
  radioButton: {
    width: 16,
    height: 16,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: '#E2E8F0',
    marginRight: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioButtonSelected: {
    borderColor: '#2563EB',
  },
  radioButtonInner: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#2563EB',
  },
  optionRowText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#64748B',
  },
  optionRowTextSelected: {
    color: '#2563EB',
    fontFamily: 'Inter-Medium',
  },
  formActions: {
    flexDirection: 'row',
    gap: 12,
  },
  cancelButton: {
    flex: 1,
  },
  addInjuryButton: {
    flex: 1,
  },
  footer: {
    paddingHorizontal: 24,
    paddingBottom: 32,
    paddingTop: 16,
  },
  continueButton: {
    width: '100%',
  },
});