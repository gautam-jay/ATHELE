import { View, Text, StyleSheet, TouchableOpacity, Platform, ScrollView } from 'react-native';
import { router } from 'expo-router';
import SafeAreaWrapper from '@/components/SafeAreaWrapper';
import Button from '@/components/Button';
import { Shield, Target, Activity, Apple, Chrome } from 'lucide-react-native';

export default function WelcomeScreen() {
  const handleGoogleSignUp = () => {
    router.push('/onboarding/basics');
  };

  const handleAppleSignUp = () => {
    router.push('/onboarding/basics');
  };

  return (
    <SafeAreaWrapper style={styles.container}>
      <ScrollView 
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.content}>
          {/* Hero Section */}
          <View style={styles.hero}>
            <View style={styles.logoContainer}>
              <View style={styles.logo}>
                <Shield size={56} color="#3B82F6" />
              </View>
              <Text style={styles.appName}>PreventIQ</Text>
            </View>
            
            <Text style={styles.tagline}>
              Prevent injuries before they happen
            </Text>
            
            <Text style={styles.description}>
              Evidence-based injury prevention tailored to your sport, position, and risk factors. Join thousands of athletes staying healthy.
            </Text>
          </View>

          {/* Features Preview */}
          <View style={styles.features}>
            <View style={styles.feature}>
              <View style={[styles.featureIcon, { backgroundColor: '#1E3A8A20' }]}>
                <Target size={20} color="#3B82F6" />
              </View>
              <View style={styles.featureContent}>
                <Text style={styles.featureTitle}>Personalized Programs</Text>
                <Text style={styles.featureDescription}>
                  Custom prevention routines based on your sport and risk profile
                </Text>
              </View>
            </View>

            <View style={styles.feature}>
              <View style={[styles.featureIcon, { backgroundColor: '#06402420' }]}>
                <Activity size={20} color="#10B981" />
              </View>
              <View style={styles.featureContent}>
                <Text style={styles.featureTitle}>Smart Monitoring</Text>
                <Text style={styles.featureDescription}>
                  Track daily metrics and get real-time injury risk alerts
                </Text>
              </View>
            </View>

            <View style={styles.feature}>
              <View style={[styles.featureIcon, { backgroundColor: '#0C4A6E20' }]}>
                <Shield size={20} color="#0891B2" />
              </View>
              <View style={styles.featureContent}>
                <Text style={styles.featureTitle}>Expert Guidance</Text>
                <Text style={styles.featureDescription}>
                  Evidence-based advice from sports medicine professionals
                </Text>
              </View>
            </View>
          </View>
        </View>

        {/* Actions */}
        <View style={styles.actions}>
          {/* Social Login Buttons */}
          <View style={styles.socialButtons}>
            {Platform.OS === 'ios' && (
              <TouchableOpacity style={styles.socialButton} onPress={handleAppleSignUp}>
                <Apple size={20} color="#FFFFFF" />
                <Text style={styles.socialButtonText}>Continue with Apple</Text>
              </TouchableOpacity>
            )}
            
            <TouchableOpacity style={[styles.socialButton, styles.googleButton]} onPress={handleGoogleSignUp}>
              <Chrome size={20} color="#4285F4" />
              <Text style={[styles.socialButtonText, styles.googleButtonText]}>Continue with Google</Text>
            </TouchableOpacity>
          </View>

          {/* Divider */}
          <View style={styles.divider}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>or</Text>
            <View style={styles.dividerLine} />
          </View>
          
          {/* Email Signup */}
          <Button
            title="Create Account with Email"
            onPress={() => router.push('/auth/signup')}
            style={styles.primaryButton}
          />
          
          <TouchableOpacity 
            style={styles.secondaryButton}
            onPress={() => router.push('/auth/login')}
          >
            <Text style={styles.secondaryButtonText}>
              Already have an account? <Text style={styles.secondaryButtonBold}>Sign In</Text>
            </Text>
          </TouchableOpacity>

          {/* Terms */}
          <Text style={styles.termsText}>
            By continuing, you agree to our{' '}
            <Text style={styles.termsLink}>Terms of Service</Text> and{' '}
            <Text style={styles.termsLink}>Privacy Policy</Text>
          </Text>
        </View>
      </ScrollView>
    </SafeAreaWrapper>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
  },
  content: {
    flex: 1,
    paddingHorizontal: 24,
    paddingTop: 40,
  },
  hero: {
    alignItems: 'center',
    marginBottom: 40,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 32,
  },
  logo: {
    width: 96,
    height: 96,
    borderRadius: 48,
    backgroundColor: '#1E3A8A20',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
    borderWidth: 2,
    borderColor: '#3B82F6',
    shadowColor: '#3B82F6',
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowOpacity: 0.3,
    shadowRadius: 24,
    elevation: 12,
  },
  appName: {
    fontSize: 36,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    letterSpacing: -0.5,
  },
  tagline: {
    fontSize: 22,
    fontFamily: 'Inter-SemiBold',
    color: '#3B82F6',
    textAlign: 'center',
    marginBottom: 16,
    letterSpacing: -0.3,
  },
  description: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#94A3B8',
    textAlign: 'center',
    lineHeight: 24,
    paddingHorizontal: 8,
  },
  features: {
    gap: 20,
  },
  feature: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  featureIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  featureContent: {
    flex: 1,
    paddingTop: 2,
  },
  featureTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  featureDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#94A3B8',
    lineHeight: 20,
  },
  actions: {
    paddingHorizontal: 24,
    paddingBottom: 32,
    paddingTop: 20,
  },
  socialButtons: {
    gap: 12,
    marginBottom: 24,
  },
  socialButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#374151',
    backgroundColor: '#1E293B',
    gap: 12,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  googleButton: {
    borderColor: '#4285F4',
    backgroundColor: '#1E293B',
  },
  socialButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
  },
  googleButtonText: {
    color: '#FFFFFF',
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 24,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: '#374151',
  },
  dividerText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#94A3B8',
    paddingHorizontal: 16,
  },
  primaryButton: {
    marginBottom: 16,
  },
  secondaryButton: {
    paddingVertical: 16,
    alignItems: 'center',
    marginBottom: 20,
  },
  secondaryButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#94A3B8',
  },
  secondaryButtonBold: {
    fontFamily: 'Inter-SemiBold',
    color: '#3B82F6',
  },
  termsText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 18,
  },
  termsLink: {
    color: '#3B82F6',
    fontFamily: 'Inter-Medium',
  },
});