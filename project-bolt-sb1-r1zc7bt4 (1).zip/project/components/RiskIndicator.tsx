import { View, Text, StyleSheet } from 'react-native';

interface RiskIndicatorProps {
  risk: 'low' | 'medium' | 'high';
  size?: 'small' | 'medium' | 'large';
}

export default function RiskIndicator({ risk, size = 'medium' }: RiskIndicatorProps) {
  const getRiskColor = () => {
    switch (risk) {
      case 'low':
        return '#10B981';
      case 'medium':
        return '#F59E0B';
      case 'high':
        return '#EF4444';
      default:
        return '#64748B';
    }
  };

  const getRiskText = () => {
    switch (risk) {
      case 'low':
        return 'Low Risk';
      case 'medium':
        return 'Medium Risk';
      case 'high':
        return 'High Risk';
      default:
        return 'Unknown';
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: getRiskColor() + '20' }]}>
      <View style={[styles.indicator, { backgroundColor: getRiskColor() }]} />
      <Text style={[styles.text, { color: getRiskColor() }]}>
        {getRiskText()}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    alignSelf: 'flex-start',
  },
  indicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 8,
  },
  text: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
  },
});